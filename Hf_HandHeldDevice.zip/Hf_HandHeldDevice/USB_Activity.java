package khdz.click.com.hf_handhelddevice.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.R;
import khdz.click.com.hf_handhelddevice.broadcase.DetactUSB;
import khdz.click.com.hf_handhelddevice.db.DBService;
import khdz.click.com.hf_handhelddevice.thread.MyClient;


public class USB_Activity extends Activity {
    public MyClient myServerTest;
    public static Thread thread;
    public DBService myService;
    public   ProgressDialog m_Dialog=null;



    public static TextView title,usbText;
    public static TextView contextText,contextText1,contextText2,contextText3;

    @Override
    protected void onDestroy() {
        super.onDestroy();
        m_Dialog.dismiss();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
  //      this.getWindow().setFlags(FLAG_HOMEKEY_DISPATCHED, FLAG_HOMEKEY_DISPATCHED);//Shielding home button
        setContentView(R.layout.activity_usb);
        initView();

            m_Dialog = ProgressDialog.show(this, "��ȴ�...", "����USB�������ݣ����Ժ�...", true);
            myService = new DBService(MyApplication.getContext());
            myServerTest = new MyClient("192.168.191.1");
            thread = new Thread(myServerTest);
            thread.start();
            DetactUSB.contextList.add((Activity) USB_Activity.this);

    }

    private void initView() {
        title= ( TextView) findViewById(R.id.title);
        title.setText("USB���ݴ���");
        usbText= ( TextView) findViewById(R.id.usb_text);
        contextText= ( TextView) findViewById(R.id.context_text);
        contextText1= ( TextView) findViewById(R.id.context_text1);
        contextText2= ( TextView) findViewById(R.id.context_text2);
        contextText3= ( TextView) findViewById(R.id.context_text3);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
//     �����򵯳�ʱֹͣѭ�������� �����Ļ �õ�������ʧ��   ����ѭ��������
        if (MotionEvent.ACTION_DOWN == event.getAction()) {
            m_Dialog.dismiss();
            this.finish();
        }
        return super.onTouchEvent(event);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {//|| event.getRepeatCount() == 0
            //���µ������BACK��
            m_Dialog.dismiss();
            this.finish();
        }
        return super.onKeyDown(keyCode, event);
    }


    public static class USBHandler extends Handler {
        String massage = "", massage0= "";
      
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
            case 0:
                massage = msg.getData().getString("text1");
                usbText.setText(massage);
                break;
              
            }

        }
    }


}


