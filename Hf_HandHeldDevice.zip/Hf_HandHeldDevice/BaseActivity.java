package khdz.click.com.hf_handhelddevice.activity;

import java.util.Timer;
import java.util.TimerTask;

import khdz.click.com.hf_handhelddevice.service.DeviceService;

import com.android.rfid.PSAM;
import com.android.rfid.Tools;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.util.Log;

public class BaseActivity extends Activity {
	public Context mycontext;
	//SerialPort
  	private  PSAM psam;						
  	public  static MyBroadcast myBroadcast;			
  	public  int cmd_flag = 0;
  	public   String sam_card="01";				//Ĭ��SAM1��Ϊ01��SAM2��Ϊ02���벻Ҫ����	
  	public   String activity = "khdz.click.com.hf_handhelddevice.activity.BaseActivity";
  	public   String action = "khdz.click.com.hf_handhelddevice.service.DeviceService";
  	//SerialPort  CMD
  	public  boolean cpu_resertTag=false;
  	public String succeedNumber="9000";
  	public String CPU_DF="00A40000022001";
  	public String CPU_RANDOM08 = "0084000008";
  	public String PSAM_GET_RESPOND="00c0000008";//08 ��ȡ8�ֽ�
  	public String PSAM_INTERNAL="0088000108";
  	public String CPU_EXITERNAL="0082000008";
  	public String CPU_READ_BINARY="00b0810008";//���ļ���������ȡ����������81�����λ����1.
  	public Timer timer;
  	//view
    String 	mycardNumber="";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mycontext=this;
		
		
		myBroadcast = new MyBroadcast();
    	IntentFilter filter = new IntentFilter();
    	filter.addAction(activity);
    	registerReceiver(myBroadcast, filter);
}
	
	/***
	 * read carder
	 * synchronized(this){}����ѭ��������������߳�ͬ����������Ӧ�޽���󣬻������ѭ����
	 * �����߳�ͬ�������յ���Ӧ�������ݺ���ִ����һ�ε�ѭ��������
     * ��������ʵ�ַ���
     */
    @Override
    protected void onResume() {
    	super.onResume();
    	psam = new PSAM(); // Used to invoke protocol wrapping commands
    	myBroadcast = new MyBroadcast();
    	IntentFilter filter = new IntentFilter();
    	filter.addAction(activity);
    	registerReceiver(myBroadcast, filter); // Register broadcast receiver, receive serial port to return data
       //The timer loop select PSAMCardSlot,check PSAMcarder is in SAM1(01) OR SAM2(02) or  psam is null.
    	timer = new Timer();
    	timer.schedule(new TimerTask() {
            @Override
            public void run() {
            synchronized(this){//this is very importance.
            	cmd_flag = 1;
                select_PSAM_CardSlot(sam_card);
            	} 
            }
        }, 1000 * 1);

    }	 
   
	@Override
    protected void onPause() {
		super.onPause();
		cmd_flag = 0;
    	unregisterReceiver(myBroadcast);
    }	
	@Override
	protected void onDestroy() {
		super.onDestroy();
	}
	

	
    private void readCard() {  
    	Intent ac = new Intent();
    	ac.setAction(action);
    	ac.putExtra("activity", activity);
    	sendBroadcast(ac);	
    	Intent sendToservice = new Intent(mycontext,DeviceService.class);  //���ڷ���ָ��
    	byte [] cmd = null;  
    	cmd_flag = 11;
    	cmd = psam.ucpu_open();
    	if(cmd != null ){
    		sendToservice.putExtra("cmd", cmd); 
    		mycontext.startService(sendToservice); 
    		}else{
    		}	    	
    }
   
    public  void select_PSAM_CardSlot(String sam_card) { 
    	Intent ac = new Intent();
    	ac.setAction(action);
    	ac.putExtra("activity", activity);
    	sendBroadcast(ac);	
    	Intent sendToservice = new Intent(mycontext,DeviceService.class);  //���ڷ���ָ��
    	byte [] cmd = null;  
		byte[] get_sam_card = Tools.HexString2Bytes(sam_card);
		cmd = psam.sam_reset(get_sam_card);
		if(cmd != null ){
    		sendToservice.putExtra("cmd", cmd);  
    		mycontext.startService(sendToservice); 
    		}else{
    		//Log.e("���ã�", "send circulationToReadCard");
    		}	    	
    }
    /**
     * �㲥�����ߣ����ڽ��շ��񷵻ص����ݣ�������UI
     * @author Administrator
     *
     */
    private class MyBroadcast extends BroadcastReceiver{
    	 SharedPreferences preferences = getSharedPreferences("cmd_backData", Context.MODE_PRIVATE);
    	 SharedPreferences preferences_sam = getSharedPreferences("SAM_CardSlot", Context.MODE_PRIVATE);
    	 int t=0;
    	 @Override
    	public void onReceive(Context context, Intent intent) {
    	String	 receivedata = intent.getStringExtra("result"); // SerialPort  call back data
    		Log.e("����CMD�������ݣ�"  + "  receivedata", receivedata);
    		if (receivedata != null) {
    			byte []receive_buffer = Tools.HexString2Bytes(receivedata);
    			switch (cmd_flag) {
    			case 1: //�ϵ�
					byte [] res= psam.resolveDataFromDevice(receive_buffer);
					if(res != null){
						// save PSAM_Cardslot
						Editor editor = preferences_sam.edit();
						editor.putString("sam_card", sam_card);
						editor.commit();
						
						// read CPU carder
						readCard();		
						
					}else{
						t++;
						if(t>=0 && t<=2){//check SAM1="01",Ten times
							sam_card="01";
						select_PSAM_CardSlot(sam_card);	
						}else if(t>2 && t<=4){// check SAM2="02",Ten times
							sam_card="02";
							select_PSAM_CardSlot(sam_card);	
						}else if(t>4){//check SAM1 and SAM2 , neither has psam.
							//"NONE_PSAM");
							t=0;
							Intent serviceIntent = new Intent();
							serviceIntent.setAction("compare_fail");
							serviceIntent.putExtra("tag", "NONE_PSAM");
							sendBroadcast(serviceIntent);
						}
						
						
					}
					
					break;
    			case 11:// cpu resert
    				
    				if(receivedata.length()>16){
    				byte []active_buffer = Tools.HexString2Bytes(receivedata);
    				byte []active_data = psam.resolveDataFromDevice(active_buffer);
    				if(active_data != null){
    				cpu_resertTag=true;
    				cmd_flag=12;
    				//String cpu_DF = "00A40000022001";cpu_DF =cpu App directory id(=2001)
    				cpu_send_cmd( cmd_flag, CPU_DF);	
    					}else{
    						cpu_resertTag=false;
    						readCard();	
    				}
    				}else{
    					cpu_resertTag=false;
    					readCard();	
    				}  
    				break;
    			case 12:// cpu select DF
    				byte [] receiver_buffer_DF = Tools.HexString2Bytes(receivedata);
    				byte []receiver_data_DF = psam.resolveDataFromDevice(receiver_buffer_DF);
    				if(receiver_data_DF != null){
    					String response=Tools.Bytes2HexString(receiver_data_DF, receiver_data_DF.length);
    					if(!response.equals("")&&response.length()>4){
    					String command = response.substring(response.length() - 4, response.length());
	    					if(command.equals(succeedNumber)){//into cpu APPdirectory success,last 4 digits are contained 9000
	    					cmd_flag = 13;
	    					//select cpu_DF into APP directory is success��Send commands to get random Numbers.
	    					//String cpu_Random08 = "0084000008";
	    					cpu_send_cmd( cmd_flag, CPU_RANDOM08);	
	    					}else{
	    					//select cpu_DF into APP directory is failed.Because the last 4 digits are not 9000.(9000 It's a sign of success)
	    					//"Data_invalid");
	    						Intent serviceIntent = new Intent();
	    						serviceIntent.setAction("compare_fail");
	    						serviceIntent.putExtra("tag", "Data_invalid");
	    						sendBroadcast(serviceIntent);
	    					}
    				}else if(!response.equals("")&&response.length()==4){
    					//response.length()==4  and select cpu_DF File into APP directory is failed��Error code is 6A82 (The file was not found).
    					//"CPU_DF_fail");
    					Intent serviceIntent = new Intent();
						serviceIntent.setAction("compare_fail");
						serviceIntent.putExtra("tag", "CPU_DF_fail");
						sendBroadcast(serviceIntent);	
    					}
    				}else{//Data failure
    					readCard();	
    					//"Data_failure");
    				}
    				break;
    			 case 13: 
    				byte []receiver_buffer_random08 = Tools.HexString2Bytes(receivedata);
    				byte []receiver_data_random08 = psam.resolveDataFromDevice(receiver_buffer_random08);
    				if(receiver_data_random08 != null){
    					String response=Tools.Bytes2HexString(receiver_data_random08, receiver_data_random08.length);
    					Log.e("13==" , ""+Tools.Bytes2HexString(receiver_data_random08, receiver_data_random08.length));
    					if(!response.equals("")&&response.length()>4){
    						String command = response.substring(response.length() - 4, response.length());
    						if(command.equals(succeedNumber)){
    							String cpu_backRandom= response.substring(0, response.length() - 4);
    						
    							  Editor editor = preferences.edit();
    								editor.putString("cpu_backRandom", cpu_backRandom);
    								editor.commit();	  
    							  //cpuȡ������ɹ����������������λpsam				
//    								cmd_flag = 14;//�ϵ�
//    								select_PSAM_cardSlot(cmd_flag,sam_card);
    								
    								//psam �ڲ���֤
    								String internalValidation= sam_card+PSAM_INTERNAL+cpu_backRandom;
	    							cmd_flag=15;
	    							psam_send_cmd(cmd_flag,internalValidation);
	    							
    						}else{
    							Intent serviceIntent = new Intent();
	    						serviceIntent.setAction("compare_fail");
	    						serviceIntent.putExtra("tag", "Data_invalid");
	    						sendBroadcast(serviceIntent);
    							//"Data_invalid");
    						}
    						}else{
    							readCard();	
    							//"CPU_RANDOM_fail");	
    						}
    				}else{
    					readCard();	
    					//"Data_failure");
    				}
    				break;
    			case 15:  //psam�ڲ����������������//B92B6975A40C17C79000
    				byte []receiver_buffer_random08mi = Tools.HexString2Bytes(receivedata);
    				byte []receiver_data_random08mi = psam.resolveDataFromDevice(receiver_buffer_random08mi);
    				if(receiver_data_random08mi != null){
    					String commend=Tools.Bytes2HexString(receiver_data_random08mi, receiver_data_random08mi.length);
    					if(commend.equals("6108")){
    						cmd_flag=16;
    						String pasm_getresponse_cmd=  sam_card+PSAM_GET_RESPOND;
    						psam_send_cmd(cmd_flag,pasm_getresponse_cmd);
    						}else{//��������
    							Intent serviceIntent = new Intent();
	    						serviceIntent.setAction("compare_fail");
	    						serviceIntent.putExtra("tag", "Data_invalid");
	    						sendBroadcast(serviceIntent);
    							//"Data_invalid");
    						}
    					
    					
    				}else{
    					readCard();	
    					//"Data_failure");
    					
    				}
    				break;
    			case 16: 
    				byte []internalValidation_buffer = Tools.HexString2Bytes(receivedata);
    				byte []internalValidation_data= psam.resolveDataFromDevice(internalValidation_buffer);
    				if(internalValidation_data != null){
    					String psam_encrypt_data=Tools.Bytes2HexString(internalValidation_data, internalValidation_data.length);
    					//Log.e("16.�㲥�������ݣ�psam�ڲ����������ok" , psam_encrypt_data);
    					if(psam_encrypt_data!=null&&!psam_encrypt_data.equals("")&&psam_encrypt_data.length()>16){
    						   String command = psam_encrypt_data.substring(psam_encrypt_data.length() - 4, psam_encrypt_data.length());
    						if(command.equals(succeedNumber)){
    							 String encrypt_data= psam_encrypt_data.substring(0, psam_encrypt_data.length() - 4);
    							//cpu�ⲿ��֤
    							cmd_flag=17;
    							
    							String externalCertification=CPU_EXITERNAL+encrypt_data;
    							cpu_send_cmd(cmd_flag,externalCertification);
    						}else{
    							//"Data_invalid");
    							Intent serviceIntent = new Intent();
	    						serviceIntent.setAction("compare_fail");
	    						serviceIntent.putExtra("tag", "Data_invalid");
	    						sendBroadcast(serviceIntent);
    						}
    					}else{
    						//Psam internal encryption random number failed.
	    					//"encrypting_fail");
    						Intent serviceIntent = new Intent();
    						serviceIntent.setAction("compare_fail");
    						serviceIntent.putExtra("tag", "Encrypting_fail");
    						sendBroadcast(serviceIntent);	
    					}	
    					
    				}else{
    					//"Data_failure");
    					readCard();	
    				}
    				break;
    			case 17: 
    				byte [] external_back = Tools.HexString2Bytes(receivedata);
    				byte []external_back_data= psam.resolveDataFromDevice(external_back);
    				if(external_back_data != null){
    					String back_Number=Tools.Bytes2HexString(external_back_data, external_back_data.length);
    					Log.e("17.�ⲿ��֤OK==" , ""+back_Number);
    					if(back_Number!=null&&!back_Number.equals("")&&back_Number.equals(succeedNumber)){
    						// String READ_BINARY="00b0810008";
    						 cmd_flag=18;
    						cpu_send_cmd(cmd_flag,CPU_READ_BINARY); 	 
    					}else{
    						//"Data_invalid");
    						Intent serviceIntent = new Intent();
    						serviceIntent.setAction("compare_fail");
    						serviceIntent.putExtra("tag", "Data_invalid");
    						sendBroadcast(serviceIntent);	
    					}
    				
    				}else{
    					//"Data_failure");
    					readCard();	
    				}
    				break;
    			case 18: 
    				byte [] cpu_back = Tools.HexString2Bytes(receivedata);
    				byte []cpu_back_data= psam.resolveDataFromDevice(cpu_back);
    				if(cpu_back_data != null){
    					String card_Number_data=Tools.Bytes2HexString(cpu_back_data, cpu_back_data.length);
    					//Log.e("18.�ⲿ��֤OK==" , ""+card_Number_data);
    					if(card_Number_data!=null&&!card_Number_data.equals("")&&card_Number_data.length()>4){
    						   String command = card_Number_data.substring(card_Number_data.length() - 4, card_Number_data.length());
    						if(command.equals(succeedNumber)){
    							 String card_Number= card_Number_data.substring(0, card_Number_data.length() - 4);
    							 byte[] card_NumberByte = Tools.HexString2Bytes(card_Number);
    								int cardNumber=Tools.bytesToInt(card_NumberByte,0);
    								Log.e("18.��ȡ����==",""+cardNumber);
    								mycardNumber=String.valueOf(cardNumber);
    								
    								Intent serviceIntent = new Intent();
    								serviceIntent.setAction("compare_succeed");
    								serviceIntent.putExtra("card", mycardNumber);
    								sendBroadcast(serviceIntent);
    								
    								
    								
    						}else{
    							//"Data_invalid");
    							Intent serviceIntent = new Intent();
        						serviceIntent.setAction("compare_fail");
        						serviceIntent.putExtra("tag", "Data_invalid");
        						sendBroadcast(serviceIntent);		
    						}
    					}else{
    						//"Data_invalid");
    						Intent serviceIntent = new Intent();
    						serviceIntent.setAction("compare_fail");
    						serviceIntent.putExtra("tag", "Data_invalid");
    						sendBroadcast(serviceIntent);	
    					}
    				
    				}else{
    					//"Data_failure");
    					readCard();	
    				}
    				break;
    			}
    		}
    		
    	}
		
		private void psam_send_cmd(int cmd_flag, String internalValidation) {
    		Intent sendToservice = new Intent(mycontext,DeviceService.class);  //���ڷ���ָ��
    		byte [] cmd = null;  
    		cmd = psam.sam_send_cmd(Tools.HexString2Bytes(internalValidation));
    		sendToservice.putExtra("cmd", cmd); 
    		mycontext.startService(sendToservice);
    	}
    	private void cpu_send_cmd(int cmd_flag, String command) {
    		Intent sendToservice = new Intent(mycontext,DeviceService.class);  //���ڷ���ָ��
    		byte [] cmd = null;  
    		cmd  = psam.ucpu_send_cmd(Tools.HexString2Bytes(command));
    		sendToservice.putExtra("cmd", cmd); 
    		mycontext.startService(sendToservice); 
    	}
    	
    
  
    }	
    
    
    
   

	
}

