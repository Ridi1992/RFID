/** Automatically generated file. DO NOT MODIFY */
package khdz.click.com.hf_handhelddevice;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}