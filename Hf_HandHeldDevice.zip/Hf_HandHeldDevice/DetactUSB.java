package khdz.click.com.hf_handhelddevice.broadcase;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.widget.Toast;

import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.activity.Socket_Activity;
import khdz.click.com.hf_handhelddevice.activity.USB_Activity;
import khdz.click.com.hf_handhelddevice.activity.WelcomeActivity;
import khdz.click.com.hf_handhelddevice.db.DBService;
import khdz.click.com.hf_handhelddevice.thread.MyClient;
import khdz.click.com.hf_handhelddevice.tools.Utils;

/**
 * Created by Administrator on 2017/7/5.
 */
//<!-- USB-->
//<receiver
//   android:name="khdz.click.com.hf_handhelddevice.broadcase.DetactUSB"
//   android:launchMode="singleTask">
//   <intent-filter android:priority="99">
//       <action android:name="myaction" />
//   </intent-filter>
//   <intent-filter android:priority="99">
//       <action android:name="android.hardware.usb.action.USB_STATE" />
//   </intent-filter>
//</receiver>
// <activity
//   android:name=".activity.USB_Activity"
//   android:launchMode="singleTask" />
public class DetactUSB   extends BroadcastReceiver {
	    public  static boolean   USBconnected =false;
	    public static  List<Activity> contextList=new ArrayList<Activity>();
	    public USB_Activity.USBHandler handler;
	    Message msg;
	    @Override
	    public void onReceive(Context context, Intent intent) {
//			abortBroadcast();//���������������ʱ�򣬹㲥���͵��˽��������������㲥�������յ���
	        handler=new USB_Activity.USBHandler();
	        String action = intent.getAction();
	         msg=new Message();
	        if (action.equals("myaction")) {
	         String name = intent.getStringExtra("name");
	       //  Toast.makeText(context, ""+ name, Toast.LENGTH_SHORT).show();

	        }  else if (action.equals("android.hardware.usb.action.USB_STATE")) {
	                USBconnected = intent.getExtras().getBoolean("connected");
	                String name = intent.getStringExtra("name");
//	                Toast.makeText(context, ""+ name, Toast.LENGTH_SHORT).show();
	            if (USBconnected) {

//	                Utils.showToast("USB is connected");
//	                //�Զ� ����usb������Activity  ֹͣѭ������
//	              if (MyClient.socketList.size()>0){
//	            	  MyClient.socketList.clear();
//	                }
//	                    Intent myIntent = new Intent(context, USB_Activity.class);
//	                    myIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//	                    context.startActivity(myIntent);
	            } else {
	                USBconnected=false;
//	                if(DetactUSB.contextList.size()==0){
//	                    Utils.showToast("USB no connected");
//	                }else{
//	                    Utils.showToast("USB no connected");
//	                    getFinish();
//	                }



	            }
	        }




	    }

	    private void sengMassage(int i, String name) {
	        msg.what=i;
	        Bundle bundle = new Bundle();
	        bundle.putString("text1", name);
	        msg.setData(bundle);
	        handler.handleMessage(msg);
	    }

	    public void getFinish() {
	        try {
	            if(MyClient.socketList.size()>0 ) {
	                MyClient.client.close();
	            }
	            if( DetactUSB.contextList.size()>0){
	          //      WelcomeActivity.IS_DOWHILE_FLAG=true;
	                for(Activity  context1: DetactUSB.contextList){
	                    context1.finish();
	                }
	            }
	            
	            
//	            Intent ootStartIntent = new Intent(context, WelcomeActivity.class);
//	            ootStartIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//	            context.startActivity(ootStartIntent);
	            
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}
