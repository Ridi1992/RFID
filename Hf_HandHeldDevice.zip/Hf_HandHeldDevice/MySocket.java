package khdz.click.com.hf_handhelddevice.thread;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.security.InvalidKeyException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.activity.Setting_Activity;
import khdz.click.com.hf_handhelddevice.activity.WelcomeActivity;
import khdz.click.com.hf_handhelddevice.broadcase.SocketReceiver;
import khdz.click.com.hf_handhelddevice.tools.DES;
import khdz.click.com.hf_handhelddevice.tools.Utils;

/**
 * Created by Administrator on 2017/8/11.
 */

//public static void getSocket(String inputServerIP) {
//	ThreadLocal<Socket> threadConnect = new ThreadLocal<Socket>(); 
//	Socket client;
//	OutputStream outStr = null;
//	InputStream inStr = null;
//	try {
//		 client = threadConnect.get();
//	        if(client == null){
//				client = new Socket(inputServerIP, 8087);
//				client.setKeepAlive(true);
//		        client.setSoTimeout(1000 * 2);
//	            threadConnect.set(client);
//	            outStr = client.getOutputStream();
//		        inStr = client.getInputStream();
//	        }
//	        MySocket myTest = new MySocket(client,inStr,outStr);
//	        Thread thread = new Thread(myTest);
//	        thread.start();
//		} catch (UnknownHostException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}		
//}
public class MySocket implements Runnable {//
    public static boolean serverSocketIsConnect= true; // Check the server link status����true==close��false==link
    public static OutputStream outStr = null;
    public static InputStream inStr = null;
    public static Socket client;
    public MySocket(Socket client,InputStream inStr,OutputStream outStr) {
    	this.client=client;
    	this.inStr=inStr;
        this.outStr=outStr;
    }

    @Override
    public void run()  {
            serverSocketIsConnect=true;
           while (serverSocketIsConnect) {//Continue to receive clients
        	   boolean isKeep= isServerClose(client,outStr);
        	   doRead( inStr, outStr);  
            }
    }
    public  Boolean isServerClose(Socket socket,OutputStream outStr){  
        try{  
         Thread.sleep(3000);
         socket.sendUrgentData(0);//����1���ֽڵĽ������ݣ�Ĭ������£���������û�п����������ݴ�������Ӱ������ͨ��  
//         outStr.write(erroe_array3);
         
         Log.e("�����������ݰ�ok", "");
         
         return false;  
        }catch(Exception se){  
        	try {
				client.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
        	Log.e("�����������ݰ�����쳣", "");
         return true;  
        }  
     }  
    private void doRead(InputStream inStr,OutputStream outStr) {
        try {
            //Э��ͷ
            byte[] buffer = new byte[1024];
            int in = inStr.read(buffer, 0, 12);
            if (in>0&&in == 12) {
            	Log.e("������tou��", "");
                serverSocketIsConnect=true;//The flag has been linked to the server
                //Record the link object and loop through the socket link at the end of the interaction to stop the port
               //Log the IP address of each link successfully, and the next time you have a network, link to the address, such as link, then return to the IP address page
               
              
                int iVersiuon = Utils.byte2intBefor4(buffer);
                int iCommand = Utils.byte2intAfter8(buffer);
                int iPacketLength = Utils.byte2intAfter12(buffer);

                //Protocol header file type
                byte[] headBuffer = new byte[1024];
                int headData = iPacketLength - in;//Length of content after baotou
                int headIn=0;
                if(headData>0 && headData<=1024) {
                    headIn = inStr.read(headBuffer, 0, headData);
                }
                //  The byte after the first 12 bytes of the protocol is the text type length filename
                if (headIn>0&&headIn == headData) {
                    final int fileType = Utils.byte2intBefor4(headBuffer); // 4 file type, 0 text ,1 head
                  
                    Log.e("�ļ�����111111111", fileType+"");
                    
                    int fileLength = Utils.byte2intAfter8(headBuffer); //8byte  long
                  //  Log.e(" after  headData content ==", fileType + "==" + iVersiuon);
                    String fileName;//pc_regester_data
                    // Determines whether the file name is included after the 4 file type + 8 length 12 bytes
                    if (headData - 12 > 0) {//have filename
                        byte[] fialNameByte = new byte[headData - 12];
                        System.arraycopy(headBuffer, 12, fialNameByte, 0, headData - 12);
                        fileName = new String(fialNameByte, 0, fialNameByte.length, "utf-8");
                    } else {//No filename
                        fileName = "pc_regester_data";
                    }
                    //  send info to pc
                    if (iCommand == 32) {
                    	 Log.e("�ļ�����beginSendData", fileType+"");
                       long indentifyfileLength = 0;//�ļ�����
                        byte[] write_iVersiuon = Utils.int2byte(iVersiuon);
                        byte[] write_iCommand = Utils.int2byte(iCommand);
                        byte[] PackageNum = Utils.int2byte(24); //����  �汾4�ֽ�+����4�ֽ�+������4�ֽ�+�ļ���С8�ֽڡ�
                        int succeed = 0;
                        byte[] writeNum = Utils.int2byte(succeed); //error code
                        File flie = new File(MyApplication.PERSIN_IDENTIFY_FILE);
                        if (!flie.isDirectory() && flie.exists()) {
                            indentifyfileLength = flie.length();
                        } else {//file not  exists()
                            indentifyfileLength = 0;
                        }
                        byte[] Length = Utils.int2byte8(indentifyfileLength); //�ļ����� 8�ֽ�
                        byte[] n1 = Utils.byteMerger(write_iVersiuon, write_iCommand);
                        byte[] n2 = Utils.byteMerger(n1, PackageNum);
                        byte[] n3 = Utils.byteMerger(n2, writeNum);
                        byte[] n4 = Utils.byteMerger(n3, Length);
                        boolean sendOver = sendIdentifyDate(outStr, indentifyfileLength, n4);
                        if (sendOver) {
                           byte[] resBuffer = new byte[1024];
                            int resInt = inStr.read(resBuffer, 0, 12);
                            if (in == 12) {
                                int v = Utils.byte2intBefor4(resBuffer);
                                int rescode =Utils. byte2intAfter8(resBuffer);
                                int l =Utils. byte2intAfter12(resBuffer); 
                                if (rescode == 31) {//32   or 31
                                	Log.e("���ݽ�����ϣ���������12333", rescode+"");
                                	 byte[] erroe_array3 =  sendCommand(2000,30,16,2);
                                	 outStr.write(erroe_array3);
                                     
                              }
                            }
                        }
                    } else {
                        // receiving the protocol header,Return OK  Command
                        byte[] n3 = sendCommand(iVersiuon,iCommand,16,0);
                        outStr.write(n3);
                        //Determines whether to send data 0
                        boolean isSave = readReceiveData(inStr, fileName, fileType, fileLength);
                        //The data processing received , receiving end of the command 31 success 0, failure: 1, 2
                        if (isSave) {
                            byte[]   receive_array3=sendCommand(iVersiuon,31,16,0);
                            outStr.write(receive_array3);
                        }
                    }//32
                } else {//Header length error <12
                    //0 succeed,  1  unkown,   2 failed
                    byte[] erroe_array3=  sendCommand(iVersiuon,iCommand,16,1);
                    outStr.write(erroe_array3);

                }

            } else {
                //Protocol error, return package;
                //0 succeed,  1  unkown,   2 failed
                byte[] erroe_array3 =  sendCommand(2000,30,16,2);
                outStr.write(erroe_array3);
            }
            //Once the interaction completes, disconnect the link and wait for the next interaction
            //   client.close();
        } catch (SocketException e) {
           e. printStackTrace();
            if(e.toString().contains("EPIPE")){
               serverSocketIsConnect=false;//End loop receiving data��and close socket.
            }
        } catch (IOException e) {
            e.printStackTrace();
            serverSocketIsConnect=false;//End loop receiving data��and close socket.Wait for the next link
       
        }
    }


    /**
     * The data interacts with the server, and each time it interacts, the corresponding information file must be deleted
     */
    private boolean readReceiveData(InputStream inputStream, String fileName, int fileType, int fileLength) throws IOException {
        boolean isSave = true;
        FileOutputStream fos=null;
        try {
            File   file=  checkFile(fileType,fileName);
            if(file!=null) {
                 fos = new FileOutputStream(file, false);// if true additional,false== cover
            }
        int iRead = 0;
        byte[] tagLength = new byte[1024];
        while (fileLength > 0) {
            int iReadLen = fileLength > tagLength.length ? tagLength.length : fileLength;
            if ((iRead = inputStream.read(tagLength, 0, iReadLen)) > 0) {
                	fos.write(tagLength, 0, iRead);
                    fileLength -= iRead;
            } else {
                isSave = false;
                break;
            }
        }
        //    if close  inputStream,socket is close,Return package is abnormal
        //      inputStream.close();
        fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return isSave;
    }
    
	
    private File checkFile(int fileType,String fileName) {
        File file = null;
        file = new File(MyApplication.LOCAL_FOLDERS);
        if (!file.isDirectory() || !file.exists()) {
        	  Utils.makeRootDirectory(MyApplication.LOCAL_FOLDERS);//makeRootDirectory
        } else {
        }
        try {
        if (fileType == 1) {
            file = new File(MyApplication.PERSIN_INFO_FILE);
            if (!file.isDirectory() && file.exists()) {
                file.delete();
            } else {
                file.createNewFile();
            }

        } else if (fileType == 2) {
            File  PhotoFile = new File(MyApplication.PHOTO_PATH);
            if(PhotoFile.isDirectory()&& PhotoFile.exists()){
                PhotoFile.delete();
                Utils.makeRootDirectory(MyApplication.PHOTO_PATH);//makeRootDirectory
            }else{
                Utils.makeRootDirectory(MyApplication.PHOTO_PATH);//makeRootDirectory
            }


            file = new File(MyApplication.PHOTO_PATH + fileName);
            MyApplication.deleteNativePhoto(MyApplication.PHOTO_PATH + fileName);
        } else if (fileType == 3) {
            file = new File(MyApplication.PERSIN_AUTH3_FILE);
            if (!file.isDirectory() && file.exists()) {
                file.delete();
            } else {
                file.createNewFile();
            }
        } else if (fileType == 4) {
            file = new File(MyApplication.PERSIN_AUTH4_FILE);
            if (!file.isDirectory() && file.exists()) {
                file.delete();
            } else {
                file.createNewFile();
            }
        } else if (fileType == 5) {
            file = new File(MyApplication.PERSIN_AUTH5_FILE);
            if (!file.isDirectory() && file.exists()) {
                file.delete();
            } else {
                file.createNewFile();
            }
        }else if (fileType == 8) {
            file = new File(MyApplication.COLLECTIVITY_INFO_FILE);
            if (!file.isDirectory() && file.exists()) {
                file.delete();
            } else {
                file.createNewFile();
            }
        }else if (fileType == 9) {
            file = new File(MyApplication.COLLECTIVITY_AUTH9_FILE);
            if (!file.isDirectory() && file.exists()) {
                file.delete();
            } else {
                file.createNewFile();
            }
        }else if (fileType == 10) {
            file = new File(MyApplication.COLLECTIVITY_AUTH10_FILE);
            if (!file.isDirectory() && file.exists()) {
                file.delete();
            } else {
                file.createNewFile();
            }
        }
       } catch (IOException e) {
            e.printStackTrace();
        }
        return  file;
    }

    //**************************************Send identification log records
    //Remove the locally identified data and then delete it.
    public boolean sendIdentifyDate(OutputStream outStr, long fileLength, byte[] n4) {
        boolean sendOver = false;
        File file = new File(MyApplication.PERSIN_IDENTIFY_FILE);
        String content = "";
        if (!file.isDirectory() && file.exists()) {
            InputStream in = null;
            try {
                in = new FileInputStream(file);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            InputStreamReader inputreader = new InputStreamReader(in);
            BufferedReader buffreader = new BufferedReader(inputreader);
            byte[] byteArray = new byte[1024];
            int len = 0;
            int temp = 0;//All read content is received using temp
            if (in != null) {
                try {
                	outStr.write(n4);
                    while ((temp = in.read(byteArray)) != -1) {    //When not finished, continue reading// while((ch=in.read(byteArray))!=-1){
                        len = len + temp;
                        outStr.write(byteArray, 0, temp);
                        if (fileLength == len) {
                            sendOver = true;
                            break;
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else{// send command
            byte[] n3 =  sendCommand(2000,32,16,0);
            try {
            	outStr.write(n3);
            } catch (IOException e) {
                e.printStackTrace();
            }
       // return;//file is not exists
    }
        return sendOver;
    }


    public   byte[] sendCommand(int versiuon,int command,int packageNum,int isSucceedNumber){
            byte[] iVersiuon = Utils.int2byte(versiuon);
            byte[] iCommand = Utils.int2byte(command);
            byte[] PackageNum = Utils.int2byte(packageNum);
            int succeed = isSucceedNumber;
            byte[] succeedNum = Utils.int2byte(succeed);
            byte[] n1 = Utils.byteMerger(iVersiuon, iCommand);
            byte[] n2 = Utils.byteMerger(n1, PackageNum);
            byte[] n3 = Utils.byteMerger(n2, succeedNum);
        return   n3;
}


}
