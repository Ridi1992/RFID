package khdz.click.com.hf_handhelddevice.adapter;

import java.util.List;

import khdz.click.com.hf_handhelddevice.R;
import khdz.click.com.hf_handhelddevice.data.PersonInfo;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.SectionIndexer;
import android.widget.TextView;

public class SortAdapter extends BaseAdapter implements SectionIndexer{
	private List<PersonInfo> list = null;
	private Context mContext;
	
	public SortAdapter(Context mContext, List<PersonInfo> list) {
		this.mContext = mContext;
		this.list = list;
	}
	
	/**
	 * ��ListView���ݷ����仯ʱ,���ô˷���������ListView
	 * @param list
	 */
	public void updateListView(List<PersonInfo> list){
		this.list = list;
		notifyDataSetChanged();
	}

	public int getCount() {
		return this.list.size();
	}

	public Object getItem(int position) {
		return list.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(final int position, View view, ViewGroup arg2) {
		ViewHolder viewHolder = null;
		final PersonInfo mContent = list.get(position);
		if (view == null) {
			viewHolder = new ViewHolder();//bar_item
			view = LayoutInflater.from(mContext).inflate(R.layout.list_item, null);
			viewHolder.list_item_ly=(LinearLayout)view.findViewById(R.id.list_item_ly);
			viewHolder.tvLetter = (TextView) view.findViewById(R.id.catalog);
			viewHolder.name = (TextView) view.findViewById(R.id.name);
			viewHolder.sex = (TextView) view.findViewById(R.id.sex);
			viewHolder.depart_name = (TextView) view.findViewById(R.id.depart_name);
			viewHolder.principal_name = (TextView) view.findViewById(R.id.principal_name);
			view.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) view.getTag();
		}
		
		 if(position%2==0){
			 viewHolder.list_item_ly.setBackgroundColor(Color.parseColor("#93C797"));
         }else if(position%2==1){
        	 viewHolder.list_item_ly.setBackgroundColor(Color.parseColor("#7F9080"));
         }
		
		//����position��ȡ���������ĸ��Char asciiֵ
		int section = getSectionForPosition(position);
		
		//�����ǰλ�õ��ڸ÷�������ĸ��Char��λ�� ������Ϊ�ǵ�һ�γ���
		if(position == getPositionForSection(section)){
			viewHolder.tvLetter.setVisibility(View.VISIBLE);
			viewHolder.tvLetter.setText(mContent.getSortLetters());
		}else{
			viewHolder.tvLetter.setVisibility(View.GONE);
		}
	
		viewHolder.name.setText(this.list.get(position).getName());
		 if(list.get(position).getSex()==0){
			 viewHolder.sex.setText(R.string.man);
         }else if(list.get(position).getSex()==1){
        	 viewHolder.sex.setText(R.string.woman);
         } else if (list.get(position).getSex() == 3) {
        	 viewHolder.sex.setText(R.string.unknownGender);
         }
		 viewHolder.depart_name.setText(list.get(position).getDepart_name());
		 viewHolder.depart_name.setText(list.get(position).getPrincipal_name());
          
		return view;

	}
	


	final static class ViewHolder {
		LinearLayout list_item_ly;
		TextView tvLetter;
		TextView name,sex,depart_name,principal_name;
	}


	/**
	 * ����ListView�ĵ�ǰλ�û�ȡ���������ĸ��Char asciiֵ
	 */
	public int getSectionForPosition(int position) {
		return list.get(position).getSortLetters().charAt(0);
	}

	/**
	 * ���ݷ��������ĸ��Char asciiֵ��ȡ���һ�γ��ָ�����ĸ��λ��
	 */
	public int getPositionForSection(int section) {
		for (int i = 0; i < getCount(); i++) {
			String sortStr = list.get(i).getSortLetters();
			char firstChar = sortStr.toUpperCase().charAt(0);
			if (firstChar == section) {
				return i;
			}
		}
		
		return -1;
	}
	
	/**
	 * ��ȡӢ�ĵ�����ĸ����Ӣ����ĸ��#���档
	 * 
	 * @param str
	 * @return
	 */
	private String getAlpha(String str) {
		String  sortStr = str.trim().substring(0, 1).toUpperCase();
		// �������ʽ���ж�����ĸ�Ƿ���Ӣ����ĸ
		if (sortStr.matches("[A-Z]")) {
			return sortStr;
		} else {
			return "#";
		}
	}

	@Override
	public Object[] getSections() {
		return null;
	}
}