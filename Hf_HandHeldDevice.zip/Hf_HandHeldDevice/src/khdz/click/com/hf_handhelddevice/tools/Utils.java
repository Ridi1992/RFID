package khdz.click.com.hf_handhelddevice.tools;



import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.R;
import khdz.click.com.hf_handhelddevice.activity.WelcomeActivity;

import org.apache.http.conn.util.InetAddressUtils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import android.widget.Toast;

/**
 * Created by Administrator on 2017/6/13.
 */

@SuppressLint("NewApi")
public class Utils {

    public static SoundPool sp ;
    public static Map<Integer, Integer> suondMap;
    public static Context context;
    private static MediaPlayer mediaPlayer = null;
    
    public  static void playerVoice(Context cot,int flag) {
        if (flag==0) {
            mediaPlayer = MediaPlayer.create(cot, R.raw.tongxing);
        } else if(flag==1) {
            mediaPlayer = MediaPlayer.create(cot, R.raw.read_carder_fail);//fail
        }else if(flag==2) {
            mediaPlayer = MediaPlayer.create(cot, R.raw.collection);
        } else if(flag==3) {
            mediaPlayer = MediaPlayer.create(cot, R.raw.no_psam);
        }else if(flag==4) {
            mediaPlayer = MediaPlayer.create(cot, R.raw.illegal);
        }else if(flag==5) {
            mediaPlayer = MediaPlayer.create(cot, R.raw.unlock_the_screen);
        }else if(flag==6) {
            mediaPlayer = MediaPlayer.create(cot, R.raw.msg);
        }
        
        if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
            mediaPlayer.setLooping(false);
            mediaPlayer.start();
        }
    }
    public  static void stopVoice(Context cot) {

        if(mediaPlayer!=null ) {//|| mediaPlayer.isPlaying()
            mediaPlayer.stop();
        }
    }
    public static void initSoundPool(Context context){
        Utils.context = context;
        sp = new SoundPool(1, AudioManager.STREAM_MUSIC, 1);
        suondMap = new HashMap<Integer, Integer>();
        suondMap.put(1, sp.load(context, R.raw.msg, 1));
    }

    public static  void play(int sound, int number){
        AudioManager am = (AudioManager)Utils.context.getSystemService(Utils.context.AUDIO_SERVICE);
        float audioMaxVolume = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

        float audioCurrentVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        float volumnRatio = audioCurrentVolume/audioMaxVolume;
        sp.play(
                suondMap.get(sound), 
                audioCurrentVolume, 
                audioCurrentVolume, 
                1, 
                number,
                1);
    }
   
    public static Bitmap getLocalBitmap(String url)  {
        Bitmap bitmap=null;
        File mFile=new File(url);//+"_image"
        if (mFile.exists()) {
             bitmap=BitmapFactory.decodeFile(url);
        }
        return bitmap;
    }
    public static String readFromSocket(InputStream in) {
        int MAX_BUFFER_BYTES = 4000;
        String msg = "";
        byte[] tempbuffer = new byte[MAX_BUFFER_BYTES];
        try {
            int numReadedBytes = in.read(tempbuffer, 0, tempbuffer.length);
            msg = new String(tempbuffer, 0, numReadedBytes, "utf-8");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return msg;
    }

   
    public static void saveBitmap(String path, Bitmap faceBitmap) {
        File lPicFile = new File(path);
        try {
            if (!lPicFile.exists()) {
                lPicFile.createNewFile();
            }
            FileOutputStream out = new FileOutputStream(lPicFile);
            faceBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);

            out.flush();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


   
    public static void makeDir(File dir) {
        if (!dir.getParentFile().exists()) {
            makeDir(dir.getParentFile());
        }
        dir.mkdir();
    }

    
    public static String getSDPath( ) {
        File sdDir = null;
        boolean sdCardExist = Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
        if (sdCardExist) {
            sdDir = Environment.getExternalStorageDirectory();
        }
        String dir = sdDir.toString();
        return dir;
    }


    public  static byte[] getPictureByte(Bitmap bmp) {
        if(bmp == null) {return null;}
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, os);
        return os.toByteArray();
    }

  
    public  static Bitmap getPictureBitmap(byte[] bt) {
        if(bt.length!=0) {

            return  BitmapFactory.decodeByteArray(bt,0,bt.length);
        }else {
            return null;
        }
    }

    public static Bitmap stringtoBitmap(String string){
        Bitmap bitmap=null;
        try {
            byte[]bitmapArray;
            bitmapArray= Base64.decode(string, Base64.DEFAULT);
            bitmap=BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.length);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return bitmap;
    }
    public static String bitmaptoString(Bitmap bitmap){
        String string=null;
        ByteArrayOutputStream bStream=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,100,bStream);
        byte[]bytes=bStream.toByteArray();
        string=Base64.encodeToString(bytes,Base64.DEFAULT);
        return string;
    }
    public static byte[] int2byte(int res) {
        byte[] targets = new byte[4];
        targets[0] = (byte) (res & 0xff);// 鏈�綆浣�
        targets[1] = (byte) ((res >> 8) & 0xff);// 娆′綆浣�
        targets[2] = (byte) ((res >> 16) & 0xff);// 娆￠珮浣�
        targets[3] = (byte) (res >>> 24);// 鏈�珮浣�鏃犵鍙峰彸绉汇�
        return targets;
    }
    public static int byte2intBefor4(byte[] buffer) {
        int  iVersiuon  = (buffer[0]& 0xff) + ((buffer[1]&0xff)<<8) + ((buffer[2]&0xff)<<16) + ((buffer[3]&0xff)<<24);
        return iVersiuon;
    }
    public static int byte2intAfter8(byte[] buffer) {
        int  iCommand  = (buffer[4]& 0xff) + ((buffer[5]&0xff)<<8) + ((buffer[6]&0xff)<<16) + ((buffer[7]&0xff)<<24);
        return iCommand;
    }
    public static int byte2intAfter12(byte[] buffer) {
        int  iPacketLength  =  (buffer[8]& 0xff) + ((buffer[9]&0xff)<<8) + ((buffer[10]&0xff)<<16) + ((buffer[11]&0xff)<<24);
        return iPacketLength;
    }
    public static byte[] int2byte8(long res) {
        byte[] targets = new byte[8];
        targets[0] = (byte) (res & 0xff);// 鏈�綆浣�
        targets[1] = (byte) ((res >> 8) & 0xff);// 娆′綆浣�
        targets[2] = (byte) ((res >> 16) & 0xff);// 娆￠珮浣�
        targets[3] = (byte) (res >>> 24 & 0xff);
        targets[4] = (byte) (res >>> 32 & 0xff);
        targets[5] = (byte) (res >>> 40 & 0xff);
        targets[6] = (byte) (res >>> 48 & 0xff);
        targets[7] = (byte) (res >>> 56 & 0xff);
        return targets;
    }
    public static long  byte8int2( byte[] buffer ) {
        int num=(buffer[0]& 0xff) + ((buffer[1]&0xff)<<8) + ((buffer[2]&0xff)<<16) + ((buffer[3]&0xff)<<24)+
                ((buffer[4]& 0xff)<<32) + ((buffer[5]&0xff) <<  40) + ((buffer[6]&0xff)<<48) + ((buffer[7]&0xff) << 56);
        return num;
    }

    public static byte[] pasmInternalAuthentication(byte[] randomNumber) {
    	  byte[] targets = new byte[5];//0088000108
          targets[0]=0x00;//
          targets[1]=(byte) 0x88;//
          targets[2]=(byte) 0x00;//鍔犲瘑
          targets[3]=(byte) 0x01;//3des瀵嗛挜鏍囪瘑鍙�082锛�      瀵嗛挜id 0x01  绫诲瀷 0xf0
          targets[4]=(byte) 0x08;//璁よ瘉鏁版嵁鐨勯暱搴�8浣�
         // targets[5]= Tools.HexString2Bytes(byte1);//璁よ瘉鏁版嵁8瀛楄妭16浣�

          byte[] InternalAuthCommand = new byte[targets.length + randomNumber.length];
          System.arraycopy(targets, 0, InternalAuthCommand, 0, targets.length);
          System.arraycopy(randomNumber, 0, InternalAuthCommand, targets.length, randomNumber.length);
          return InternalAuthCommand;
    }
    
    public static byte[] cpuExternalCertification(byte[] randomNumber ) {//External certification
        byte[] targets = new byte[5];//0082003908
        targets[0]=0x00;//
        targets[1]=(byte) 0x82;//
        targets[2]=(byte) 0x00;//
        targets[3]=(byte) 0x39;//澶栭儴璁よ瘉瀵嗛挜鏍囪瘑鍙�x39   3des瀵嗛挜鏍囪瘑鍙�082锛氭垨瀵嗛挜鏍囪瘑鍙�0/01
        targets[4]=(byte) 0x08;//璁よ瘉鏁版嵁鐨勯暱搴�8浣�

        byte[] externalAuthCommand = new byte[targets.length + randomNumber.length];
        System.arraycopy(targets, 0, externalAuthCommand, 0, targets.length);
        System.arraycopy(randomNumber, 0, externalAuthCommand, targets.length, randomNumber.length);
        return externalAuthCommand;
    }


public static byte[] byteMerger(byte[] byte1,byte[] byte2){
    byte[] byte3=new byte[byte1.length+byte2.length];
    System.arraycopy(byte1,0,byte3,0,byte1.length);
    System.arraycopy(byte2,0,byte3,byte1.length,byte2.length);
    return byte3;
}

   
    public  static String getDateTime() {
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new Date());
    }
    
    public  static String formatLongTime(long time) {
        SimpleDateFormat format =   new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
        String d = format.format(time);
      //  Date date=format.parse(d);
        return d;
    }
    public File makeFilePath(String filePath, String fileName) {
        File file = null;
        makeRootDirectory(filePath);
        try {
            file = new File(filePath + fileName);
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return file;
    }

    public static void makeRootDirectory(String filePath) {
        File file = null;
        try {
            file = new File(filePath);
            if (!file.exists()) {
                file.mkdir();
            }else{
                file.delete();
            }
        } catch (Exception e) {
          //  Log.i("error:", e + "");
        }
    }


   
    public static boolean network(Context context) {
        ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if(connectivity==null){
            return false;
        }else{
            NetworkInfo info = connectivity.getActiveNetworkInfo();
            if(info==null){
                return false;
            }else{
                if(info.isAvailable()&&info.isConnected()){
               // Log.e("鍦板潃=="+getLocalIpAddress());
                    return true;
                }
            }
        }
        return false;
    }
    
    public static String getLocalIpAddress() {  
        try {  
            for (Enumeration<NetworkInterface> en = NetworkInterface  
                            .getNetworkInterfaces(); en.hasMoreElements();) {  
                        NetworkInterface intf = en.nextElement();  
                       for (Enumeration<InetAddress> enumIpAddr = intf  
                                .getInetAddresses(); enumIpAddr.hasMoreElements();) {  
                            InetAddress inetAddress = enumIpAddr.nextElement();  
//                            if (!inetAddress.isLoopbackAddress()) {  
//                            	return inetAddress.getHostAddress().toString();  
//                            }
                            String ipv4="";
                            if (!inetAddress.isLoopbackAddress() && InetAddressUtils.isIPv4Address(ipv4=inetAddress.getHostAddress()))   
                            {   
                                return ipv4;  
                            }  
                       }  
                    }  
                } catch (SocketException ex) {  
                    Log.e("WifiPreference IpAddress", ex.toString());  
                }  
        
    	
    	
    	
    	return null;  
}  
  
    
    public  static void getDialog(Context context ,int i) {
        Dialog myDialog = null;
        if (myDialog == null) {
          myDialog = new AlertDialog.Builder(context).create();
        }
        myDialog.setCanceledOnTouchOutside(true);
        myDialog.setCancelable(true);//true
        myDialog.show();
        WindowManager.LayoutParams lp = myDialog.getWindow().getAttributes();
           
        if (MyApplication.GLOBAL_SCREEN_ORIENTATION_FLAG) {
            lp.width = WelcomeActivity.screenWidth - 50; //display.getWidth() - 50
            lp.height = WelcomeActivity.screenHeigh / 3;//-200
        } else {
        	lp.width = WelcomeActivity.screenWidth / 2; //display.getWidth() - 50
        	lp.height = WelcomeActivity.screenHeigh / 2;//-200
        }
        lp.dimAmount = 0f;
        myDialog.getWindow().setAttributes(lp);
        myDialog.getWindow().setContentView(R.layout.no_data_dialog);
//        TextView   text=(TextView)   myDialog.getWindow().findViewById(R.id.text);

    }

/*********************
 *
 */
private static Toast toast;
public  static void showToast(String info){
    if (toast==null) {
        toast = Toast.makeText(MyApplication.getContext(), info, Toast.LENGTH_LONG);
    }else {
        toast.setText(info);
    }
    toast.show();
}



}
