package khdz.click.com.hf_handhelddevice;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import khdz.click.com.hf_handhelddevice.data.CollectiveCardAuthorizationDate;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardAuthorizationTime;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardInfo;
import khdz.click.com.hf_handhelddevice.data.CollectivePersonInfo;
import khdz.click.com.hf_handhelddevice.data.PersonAuthorizationDate;
import khdz.click.com.hf_handhelddevice.data.PersonAuthorizationTime;
import khdz.click.com.hf_handhelddevice.data.PersonDeviceInfo;
import khdz.click.com.hf_handhelddevice.data.PersonInfo;
import khdz.click.com.hf_handhelddevice.tools.DES;
import khdz.click.com.hf_handhelddevice.tools.Utils;

/**
 * Created by Administrator on 2017/8/10.
 */

public class FileDataHelp {

    public static  CollectiveCardInfo collectiveCard(String path,String card_num) {
    	CollectiveCardInfo collectiveCardInfo=new CollectiveCardInfo();
    	CollectivePersonInfo info;
    	List<CollectivePersonInfo>  myList=new  ArrayList<CollectivePersonInfo>();
        String line;
        File file = new File(path);
        if (!file.isDirectory() && file.exists()) {
            try {
                InputStream in = new FileInputStream(file);
                BufferedReader buffer = null;
                    buffer = new BufferedReader(new InputStreamReader(in));//in,"GBK"
                if (buffer != null) {
                    try {
                        while (true) {
                            if ((line = buffer.readLine()) != null) {
                           // String mac=".*[a-zA-Z].*[0-9]|.*[0-9].*[a-zA-Z]";//"^\\w+$|((?=[\\x21-\\x7e]+)[^A-Za-z0-9])";
                            	try {
										JSONObject object = new JSONObject(line);//line
										   int id=  object.getInt("id");
										   String person_sn=  object.getString("person_sn");
										   String camera_name=  object.getString("camera_name");
										   String at_position=  object.getString("at_position");
										   String card_number=  object.getString("card_number");
										   String camera_sn=  object.getString("camera_sn");
										  
										 if(card_number.equals(card_num)){
										   info=new CollectivePersonInfo();
										   info.setId(id);
										   info.setPerson_sn(person_sn);
										   info.setCamera_name(camera_name);
										   info.setAt_position(at_position);
										   info.setCard_number(card_number);
										   info.setCamera_sn(camera_sn);
										   myList.add(info);
									
										   collectiveCardInfo.setCollective_carder_id(id);
										   collectiveCardInfo.setCarderNumber(card_number);
										   collectiveCardInfo.setCollectivePersonInfo(myList);
										 }
									} catch (JSONException e) {
										e.printStackTrace();
									}
                                 
                                

                            } else {
                                break;
                            }

                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return collectiveCardInfo;
    }
    public static List<CollectivePersonInfo> collectiveCardList(String path) {
    	CollectivePersonInfo info;
    	List<CollectivePersonInfo>  myList=new  ArrayList<CollectivePersonInfo>();
        String line;
        File file = new File(path);
        if (!file.isDirectory() && file.exists()) {
            try {
                InputStream in = new FileInputStream(file);
                BufferedReader buffer = null;
                    buffer = new BufferedReader(new InputStreamReader(in));//in,"GBK"
                if (buffer != null) {
                    try {
                        while (true) {
                            if ((line = buffer.readLine()) != null) {
                            	try {
										JSONObject object = new JSONObject(line);//line
										   int id=  object.getInt("id");
										   String person_sn=  object.getString("person_sn");
										   String camera_name=  object.getString("camera_name");
										   String at_position=  object.getString("at_position");
										   String card_number=  object.getString("card_number");
										   String camera_sn=  object.getString("camera_sn");
										  
										  
										   for(int i=0;i<myList.size();i++){
											   if(myList.get(i).getCard_number().trim().equals(card_number)){
												   myList.remove(i);
												   i--;
											   }
										   }
										   info=new CollectivePersonInfo();
										   info.setId(id);
										   info.setPerson_sn(person_sn);
										   info.setCamera_name(camera_name);
										   info.setAt_position(at_position);
										   info.setCard_number(card_number);
										   info.setCamera_sn(camera_sn);
										   myList.add(info);
										 } catch (JSONException e) {
										e.printStackTrace();
									}
                                 
                                

                            } else {
                                break;
                            }

                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return myList;
    } 
    public static CollectiveCardAuthorizationDate collectiveCardDate(String path,int collective_carder_id) {
    	CollectiveCardAuthorizationDate info=new CollectiveCardAuthorizationDate();
    	String line;
        File file = new File(path);
        if (!file.isDirectory() && file.exists()) {
            try {
                InputStream in = new FileInputStream(file);
                BufferedReader buffer = null;
                    buffer = new BufferedReader(new InputStreamReader(in));//in,"GBK"
                if (buffer != null) {
                    try {
                        while (true) {
                            if ((line = buffer.readLine()) != null) {
                                    try {
										JSONObject object = new JSONObject(line);
										   int collective_card_id=  object.getInt("collective_card_id");
										   if(collective_card_id==collective_carder_id){
											  String date_flag=  object.getString("date_flag");
											  String date_start=  object.getString("date_start");
											  String date_end=  object.getString("date_end");
											  info.setCollective_card_id(collective_card_id);
											  info.setDate_flag(date_flag);
											  info.setDate_start(date_start);
											  info.setDate_end(date_end);
											  break;
										  }
                                    } catch (JSONException e) {
										e.printStackTrace();
									}
                            } else {
                                break;
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
		return info;
		
	}
    
    public static List<CollectiveCardAuthorizationTime>  collectiveCardTime(String path,	int collective_carder_id) {
    	 CollectiveCardAuthorizationTime info;
    	 List<CollectiveCardAuthorizationTime>  myList=new  ArrayList<CollectiveCardAuthorizationTime>();
    	String line;
        File file = new File(path);
        if (!file.isDirectory() && file.exists()) {
            try {
                InputStream in = new FileInputStream(file);
                BufferedReader buffer = null;
                    buffer = new BufferedReader(new InputStreamReader(in));//in,"GBK"
                if (buffer != null) {
                    try {
                        while (true) {
                            if ((line = buffer.readLine()) != null) {
                                    try {
										JSONObject object = new JSONObject(line);
										   int collective_card_id=  object.getInt("collective_card_id");
										   if(collective_card_id==collective_carder_id){
											 info=new CollectiveCardAuthorizationTime();
											  String week_info=  object.getString("week_info");
											  String start_time=  object.getString("start_time");
											  String end_time=  object.getString("end_time");
											  info.setCollective_card_id(collective_card_id);
											  info.setWeek_info(week_info);
											  info.setStart_time(start_time);
											  info.setEnd_time(end_time);
											  myList.add(info) ;
										  }
                                    } catch (JSONException e) {
										e.printStackTrace();
									}
                            } else {
                                break;
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
		return myList;	
	}
    public static  PersonInfo compareCard(String path,String card_num) {
        // MyApplication.PERSIN_INFO_FILE;
        boolean flag = false;
        String content = "";
        String line;
        File file = new File(path);
        PersonInfo personInfo = null;
        List<PersonInfo> personInfoList=new ArrayList<PersonInfo>();
        if (!file.isDirectory() && file.exists()) {
            try {
                InputStream in = new FileInputStream(file);
                BufferedReader buffer = new BufferedReader(new InputStreamReader(in));
                personInfo = new PersonInfo();
                if (buffer != null) {
                    try {
                        while (true) {
                            if ((line = buffer.readLine()) != null) {
                                content = line;
                                try {
                                    JSONObject obj = new JSONObject(content);
                                    String person_sn = obj.getString("person_sn");
                                    String name = obj.getString("name");
                                    int sex = obj.getInt("sex");
                                    String work_sn = obj.getString("work_sn");
                                    String smartcard_num = obj.getString("smartcard_num");//id_card
                                    String depart_name = obj.getString("depart_name");
                                    String myprincipal_name = obj.getString("principal_name");
                                    String person_iris_sn = obj.getString("person_iris_sn");
                                    int photo_flag = obj.getInt("photo_flag");
                                   
                                    if (   (smartcard_num != null && !smartcard_num.equals("")&& card_num.equals(smartcard_num)) 
                                       ||  (smartcard_num != null && !smartcard_num.equals("")&& card_num.equals(person_sn))   ) {
                                    	personInfo.setPerson_sn(person_sn);
                                        personInfo.setName(name);
                                        personInfo.setSex(sex);
                                        personInfo.setWork_sn(work_sn);
                                        personInfo.setId_card(smartcard_num);
                                        personInfo.setDepart_name(depart_name);
                                        personInfo.setPrincipal_name(myprincipal_name);
                                        personInfo.setPerson_iris_sn(person_iris_sn);
                                        personInfo.setPhoto_flag(photo_flag);
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            } else {
                                break;
                            }

                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return personInfo;
    }
    public static  List<PersonInfo> selectPersonInfoList(String path) {
        // MyApplication.PERSIN_INFO_FILE;
        boolean flag = false;
        String content = "";
        String line;
        File file = new File(path);
        List<PersonInfo> personInfoList=new ArrayList<PersonInfo>();
        if (!file.isDirectory() && file.exists()) {
            try {
                InputStream in = new FileInputStream(file);
                BufferedReader buffer = new BufferedReader(new InputStreamReader(in));

                if (buffer != null) {
                    try {
                        while (true) {
                            if ((line = buffer.readLine()) != null) {
                                content = line;
                                try {
                                    JSONObject obj = new JSONObject(content);
                                    String person_sn = obj.getString("person_sn");
                                    String name = obj.getString("name");
                                    int sex = obj.getInt("sex");
                                    String work_sn = obj.getString("work_sn");
                                    String smartcard_num = obj.getString("smartcard_num");//id_card
                                    String depart_name = obj.getString("depart_name");
                                    String myprincipal_name = obj.getString("principal_name");
                                    String person_iris_sn = obj.getString("person_iris_sn");
                                    int photo_flag = obj.getInt("photo_flag");
                                    PersonInfo personInfo =  personInfo = new PersonInfo();
                                        personInfo.setPerson_sn(person_sn);
                                        personInfo.setName(name);
                                        personInfo.setSex(sex);
                                        personInfo.setWork_sn(work_sn);
                                        personInfo.setId_card(smartcard_num);
                                        personInfo.setDepart_name(depart_name);
                                        personInfo.setPrincipal_name(myprincipal_name);
                                        personInfo.setPerson_iris_sn(person_iris_sn);
                                        personInfo.setPhoto_flag(photo_flag);

                                    personInfoList.add(personInfo);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            } else {
                                return personInfoList;
                            }

                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return personInfoList;
    }

	


    public static PersonDeviceInfo compareCardPersonAuthDevice(String path, String personSn) {
        String content = "";
        String line;
        File file = new File(path);
        PersonDeviceInfo deviceInfo = null;
        if (!file.isDirectory()) {
            InputStream in = null;
            try {
                deviceInfo = new PersonDeviceInfo();
                in = new FileInputStream(file);
                BufferedReader buffer = new BufferedReader(new InputStreamReader(in));
                if (buffer != null) {
                    while (true) {
                        try {
                            if ((line = buffer.readLine()) != null) {
                                content = line;
                                try {
                                    JSONObject obj = new JSONObject(content);
                                    String person_sn = obj.getString("person_sn");
                                    String person_group = obj.getString("person_group");
                                    String person_assignmode = obj.getString("person_assignmode");
                                    String camera_sn = obj.getString("camera_sn");
                                    String at_position = obj.getString("at_position");
                                    String camera_name = obj.getString("camera_name");


                                    if (person_sn != null && !person_sn.equals("") && personSn.equals(person_sn)) {
                                        deviceInfo.setPerson_sn(person_sn);
                                        deviceInfo.setPerson_group(person_group);
                                        deviceInfo.setPerson_assignmode(person_assignmode);
                                        deviceInfo.setCamera_sn(camera_sn);
                                        deviceInfo.setAt_position(at_position);
                                        deviceInfo.setCamera_name(camera_name);
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            } else {
                                break;
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }


        }

        return deviceInfo;
    }
    public static String getDeviceName(String path) {
        String content = "",deviceName="";
        String line;
        File file = new File(path);
        PersonDeviceInfo deviceInfo = null;
        if (!file.isDirectory()) {
            InputStream in = null;
            try {
                deviceInfo = new PersonDeviceInfo();
                in = new FileInputStream(file);
                BufferedReader buffer = new BufferedReader(new InputStreamReader(in));
                if (buffer != null) {
                    while (true) {
                        try {
                            if ((line = buffer.readLine()) != null) {
                                content = line;
                                try {
                                    JSONObject obj = new JSONObject(content);
//                                    String person_sn = obj.getString("person_sn");
//                                    String person_group = obj.getString("person_group");
//                                    String person_assignmode = obj.getString("person_assignmode");
//                                    String camera_sn = obj.getString("camera_sn");
//                                    String at_position = obj.getString("at_position");
                                    String camera_name = obj.getString("camera_name");
                                    if (camera_name != null && !camera_name.equals("") ) {
                                    	deviceName=camera_name;
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            } else {
                                break;
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }


        }

        return deviceName;
    }
    public static PersonAuthorizationDate compareCardPersonAuthDeviceData(String path,String personSn) {
        String content="";
        String line;
        File file=new File(path);
        PersonAuthorizationDate data=new PersonAuthorizationDate();
        if(!file.isDirectory()) {
            InputStream in = null;
            try {
                in = new FileInputStream(file);
            } catch (FileNotFoundException e) {e.printStackTrace();}
            BufferedReader buffer = new BufferedReader(new InputStreamReader(in));
            if (buffer != null) {
                while (true) {
                    try {
                        if ((line = buffer.readLine()) != null) {
                            content = line;
                            JSONObject obj=new JSONObject(content);
                            String person_sn=   obj.getString("person_sn");
                            String datespace_flag=   obj.getString("datespace_flag");
                            String date_from=   obj.getString("date_from");
                            String date_to=   obj.getString("date_to");
                            if(person_sn != null && !person_sn.equals("") && personSn.equals(person_sn)){
                                data.setPerson_sn(person_sn);
                                data.setDatespace_flag(datespace_flag);
                                data.setDate_from(date_from);
                                data.setDate_to(date_to);
                            }

                        }else{
                            break;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return data;
    }

    public static   List<PersonAuthorizationTime>  compareCardPersonAuthDeviceTime(String path,String personSn) {
        String content="";
        String line;
        File file=new File(path);

        List<PersonAuthorizationTime>  timeInfoList=new ArrayList<PersonAuthorizationTime>();

        if(!file.isDirectory()) {
            InputStream in = null;
            try {
                in = new FileInputStream(file);
                BufferedReader buffer = new BufferedReader(new InputStreamReader(in));
                if(buffer!=null) {
                    //分行读取
                    while (true) {
                        try {
                            if ((line = buffer.readLine()) != null) {
                                content = line;
                                try {
                                    JSONObject obj=new JSONObject(content);
                                    String person_sn=   obj.getString("person_sn");
                                    String person_group=   obj.getString("person_group");
                                    String time_start=   obj.getString("time_start");
                                    String time_end=   obj.getString("time_end");
                                    String week_info=   obj.getString("week_info");
                                  if(person_sn != null && !person_sn.equals("") && personSn.equals(person_sn)) {
                                      PersonAuthorizationTime timeInfo=new PersonAuthorizationTime();
                                      timeInfo.setPerson_sn(person_sn);
                                      timeInfo.setPerson_group(person_group);
                                      timeInfo.setTime_start(time_start);
                                      timeInfo.setTime_end(time_end);
                                      timeInfo.setWeek_info(week_info);
                                      timeInfoList.add(timeInfo);
                                  }


                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                            }else{
                                break;
                            }
                        } catch (IOException e) {e.printStackTrace();}
                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }


        }
        return timeInfoList;
    }


    public static PersonAuthorizationDate comparePersonAuthDeviceData(String path,String sn) {
        PersonAuthorizationDate data=new PersonAuthorizationDate();

        String content="";
        String line;
        File file=new File(path);
        if(!file.isDirectory()) {
            InputStream in = null;
            try {
                in = new FileInputStream(file);
                BufferedReader buffer = new BufferedReader(new InputStreamReader(in));
                if(buffer!=null) {
                    while (true) {
                        try {
                            if ((line = buffer.readLine()) != null) {
                                content = line;
                                try {
                                    JSONObject obj=new JSONObject(content);
                                    String person_sn=   obj.getString("person_sn");
                                    String datespace_flag=   obj.getString("datespace_flag");
                                    String date_from=   obj.getString("date_from");
                                    String date_to=   obj.getString("date_to");
                                    if(sn.equals(person_sn)) {
                                        data.setPerson_sn(person_sn);
                                        data.setDatespace_flag(datespace_flag);
                                        data.setDate_from(date_from);
                                        data.setDate_to(date_to);
                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                            }else{
                                break;
                            }
                        } catch (IOException e) {e.printStackTrace();}
                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }


        }
        return data;
    }

    public static PersonAuthorizationTime comparePersonAuthDeviceTime(String path, String sn) {
        PersonAuthorizationTime timeInfo=new PersonAuthorizationTime();
        String content="";
        String line;
        File file=new File(path);
        if(!file.isDirectory()) {
            InputStream in = null;
            try {
                in = new FileInputStream(file);
                BufferedReader buffer = new BufferedReader(new InputStreamReader(in));
                if(buffer!=null) {
                    while (true) {
                        try {
                            if ((line = buffer.readLine()) != null) {
                                content = line;
                                try {
                                    JSONObject obj=new JSONObject(content);
                                    String person_sn=   obj.getString("person_sn");
                                    String person_group=   obj.getString("person_group");
                                    String time_start=   obj.getString("time_start");
                                    String time_end=   obj.getString("time_end");
                                    String week_info=   obj.getString("week_info");
                                    if(sn.equals(person_sn)) {
                                        timeInfo.setPerson_sn(person_sn);
                                        timeInfo.setPerson_group(person_group);
                                        timeInfo.setTime_start(time_start);
                                        timeInfo.setTime_end(time_end);
                                        timeInfo.setWeek_info(week_info);
                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                            }else{
                                break;
                            }
                        } catch (IOException e) {e.printStackTrace();}
                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return timeInfo;
    }

	


	

   
   
}