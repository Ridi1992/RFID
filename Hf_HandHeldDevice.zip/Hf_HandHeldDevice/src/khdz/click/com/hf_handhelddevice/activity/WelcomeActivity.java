package khdz.click.com.hf_handhelddevice.activity;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import com.android.rfid.PSAM;
import com.android.rfid.Tools;

import khdz.click.com.hf_handhelddevice.CompareCarder;
import khdz.click.com.hf_handhelddevice.FileDataHelp;
import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.R;
import khdz.click.com.hf_handhelddevice.adapter.SpinnerArrayAdapter;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardAuthorizationDate;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardAuthorizationTime;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardInfo;
import khdz.click.com.hf_handhelddevice.service.DeviceService;
import khdz.click.com.hf_handhelddevice.tools.Utils;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class WelcomeActivity extends Activity {
	//windows
	private int w=0;
	private String[] settingOptions ;
	private List<String> settingList;	
	public  DisplayMetrics dm;
	public  static int screenWidth, screenHeigh;
	public  static final int FLAG_HOMEKEY_DISPATCHED = 0x80000000; //You need to define
	//views
	private    TextView showText;
	private static   TextView mTime;
	private static   TextView mYear;
	private static   TextView deviceIp;
	private     Spinner mySpinner;
	
	private MyHandler handler;
	private String UID="";
	//SerialPort
	public   Context context; 
	private  PSAM psam;						
	private  MyBroadcast myBroadcast;			
	public  int cmd_flag = 0;
	public   String sam_card="02";				//默认SAM1卡为01，SAM2卡为02，请不要更改	
	public   String activity = "khdz.click.com.hf_handhelddevice.activity.WelcomeActivity";
	public  boolean cpu_resertTag=false;
	public String succeedNumber="9000";
	//SerialPort  CMD
	public String CPU_DF="00A40000022001";
	public String CPU_RANDOM08 = "0084000008";
	public String PSAM_GET_RESPOND="00c0000008";//08 读取8字节
	public String PSAM_INTERNAL="0088000108";
	public String CPU_EXITERNAL="0082000008";
	public String CPU_READ_BINARY="00b0810008";//短文件描述符读取，所以设置81，最高位设置1.
	public Timer PSAM_timer,timer;
	private    CompareCarder compareCarder=null;
	public Intent sendToservice ;
	//bean 
	
	    @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        this.getWindow().setFlags(FLAG_HOMEKEY_DISPATCHED, FLAG_HOMEKEY_DISPATCHED);//Shielding home button
	        setContentView(R.layout.activity_welcome);
	        context=this;
	        initWindows();
	        initView();
	        initSpinner();
	      // update time
	        handler = new MyHandler();
	        new TimeThread().start();
	        
	      
	        sendToservice = new Intent(context,DeviceService.class); 
	    	sendToservice.putExtra("cmd", "");  
    		sendToservice.putExtra("activity", activity); 
	    }
		private void initWindows() {
	        dm = new DisplayMetrics();
	        getWindowManager().getDefaultDisplay().getMetrics(dm);
	        screenWidth = dm.widthPixels;
	        screenHeigh = dm.heightPixels;
	    
	    }
		 private void initView() {
		    	showText=(TextView)findViewById(R.id.showText);
		    	mTime=(TextView)findViewById(R.id.mTime);
		    	mYear=(TextView)findViewById(R.id.mYear);
		    	deviceIp=(TextView)findViewById(R.id.device_ip);
		    	
		    	mySpinner=(Spinner)findViewById(R.id.my_spinner);
		    
		    	mTime.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View arg0) {
						 select_PSAM_CardSlot(sam_card);	
					}
				});
		    	
		    	
		        
		 }
		
		 private void initSpinner() {		 
		        settingList = new ArrayList<String>();
		        settingOptions = this.getResources().getStringArray(R.array.settingArray);
		        for(String power:settingOptions){
		            settingList.add(power);
		        }
		        //if(settingList!=null&&settingList.size()>0){
		        SpinnerArrayAdapter adapter = new SpinnerArrayAdapter(this,settingList);
		        mySpinner.setAdapter(adapter);
		        mySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
		            @Override
		            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
		                switch (position) {
		                    case 0:
		                        if (!MyApplication.GLOBAL_SCREEN_ORIENTATION_FLAG) {
		                            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		                            MyApplication.GLOBAL_SCREEN_ORIENTATION_FLAG = true;
		                        }
		                        break;
		                    case 1:
		                        if (MyApplication.GLOBAL_SCREEN_ORIENTATION_FLAG) {
		                            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		                            MyApplication.GLOBAL_SCREEN_ORIENTATION_FLAG = false;
		                        }
		                        break;
		                  
		                }
		            }

		            @Override
		            public void onNothingSelected(AdapterView<?> parent) {

		            }
		        });
		       // }
		    }
	    public class TimeThread extends Thread {
	        @Override
	        public void run() {
	            super.run();
	            do {
	                try {
	                    Thread.sleep(1000);
	                    Message msg = new Message();
	                    msg.what = 60;
	                    handler.sendMessage(msg);
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            } while (true);
	        }
	    }
	  
	    public static class MyHandler extends Handler {
	        public void handleMessage(Message msg) {
	             super.handleMessage(msg);
	            switch (msg.what) {	
	            case 1:
	            	 break;
	                case 60:
	                    Date date = new Date();
	                    SimpleDateFormat fomt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss E");
	                    String systemTime = fomt.format(date);
	                    String[] timeArrsys = systemTime.toString().split(" ");
	                    mTime.setText(timeArrsys[1]);
	                    mYear.setText(timeArrsys[0].toString() + "/" + timeArrsys[2].toString());
	                    break;
	            }

	        }
	    }  
	    
	    

	    
	   
	    
	    private void setDevicesName() {
			 if(Utils.getLocalIpAddress()!=null){
	    	     String deviceName= FileDataHelp.getDeviceName(MyApplication.PERSIN_AUTH3_FILE);
	    	       if (deviceName == null ||deviceName.equals("") ) {
	    	    	 deviceIp.setText(Utils.getLocalIpAddress());
                  }else{
	        	     deviceIp.setText(deviceName);
                  }
	         }else {
	          deviceIp.setText(MyApplication.getIMEI());
	         }
			
		}
	    
	    //Close the system menu button
	    public boolean onKeyDown(int keyCode, KeyEvent event) {
	        if (keyCode == event.KEYCODE_HOME) {
	            return true;
	        }else
	        if (keyCode == event.KEYCODE_MENU) {
	             startActivity(new Intent(Settings.ACTION_SETTINGS));
	             //return true;
	        }else
	        if (keyCode == KeyEvent.KEYCODE_BACK ) {
	        	 Intent myIntent = new Intent(this, Setting_Activity.class);
                 myIntent.putExtra("Tag", "main");
                 startActivity(myIntent);
	        	
	            //return true;
	        }
	        return super.onKeyDown(keyCode, event);
	    }    
	    
	    
	    
	    
	    
	    
	    /***
		 * read carder
	     * must be implemented
	     */
	    @Override
	    protected void onResume() {
	    	super.onResume();
        	
	    	setDevicesName();
	    	  getPsam();
	    	

	    }	 
	 
		
		private void getPsam() {
			psam = new PSAM(); // Used to invoke protocol wrapping commands
	        compareCarder=new CompareCarder(context);
	    	myBroadcast = new MyBroadcast();
	    	IntentFilter filter = new IntentFilter();
	    	filter.addAction(activity);
	    	registerReceiver(myBroadcast, filter); // Register broadcast receiver, receive serial port to return data
	       //The timer loop select PSAMCardSlot,check PSAMcarder is in SAM1(01) OR SAM2(02) or  psam is null.
	   	    sendToservice = new Intent(context,DeviceService.class);  //用于发送指令
	   	   // get SAM_CardSlot
	         SharedPreferences preferences = getSharedPreferences("SAM_CardSlot", Context.MODE_PRIVATE);
	         sam_card=preferences.getString("sam_card", "02");
	    	 
	   	    PSAM_timer = new Timer();
	    	PSAM_timer.schedule(new TimerTask() {
	            @Override
	            public void run() {
	            synchronized(this){//this is very importance.
	            select_PSAM_CardSlot(sam_card);
	            		
	            	} 
	            }
	        }, 1000 * 2);
			
		}
		
		
		
		@Override
	    protected void onPause() {
			super.onPause();
				 cmd_flag = 0;
				 unregisterReceiver(myBroadcast);  
				 stopService(sendToservice);
				  
	    }	
		
	  
	    
	    
	    
		
		private void readCard() {  
	    	//Intent sendToservice = new Intent(context,DeviceService.class);  //用于发送指令
	    	byte [] cmd = null;  
	    	cmd_flag = 11;
	    	cmd = psam.ucpu_open();
	    	if(cmd != null ){
	    		sendToservice.putExtra("cmd", cmd); 
	    		sendToservice.putExtra("activity", activity);
	    		context.startService(sendToservice); 
	    		}else{
	    		}	    	
	    }
	    public  void select_PSAM_CardSlot(String sam_card) {  
	    	//Intent sendToservice = new Intent(context,DeviceService.class);  //用于发送指令
	    	byte [] cmd = null;  
	    	cmd_flag = 1;
			byte[] get_sam_card = Tools.HexString2Bytes(sam_card);
			cmd = psam.sam_reset(get_sam_card);
			if(cmd != null ){
	    		sendToservice.putExtra("cmd", cmd); 
	    		sendToservice.putExtra("activity", activity); 
	    		context.startService(sendToservice); 
	    		}else{
	    		//Log.e("设置：", "send circulationToReadCard");
	    		}	    	
	    }
	    /**
	     * Broadcast receiver, used to receive the data returned by the service, and update the UI
	     * @author Administrator
	     *
	     */
	    private class MyBroadcast extends BroadcastReceiver{
	    	 SharedPreferences preferences = getSharedPreferences("cmd_backData", Context.MODE_PRIVATE);
	    	 SharedPreferences preferences_sam = getSharedPreferences("SAM_CardSlot", Context.MODE_PRIVATE);
	    	 int t=0;
	    	 @Override
	    	public void onReceive(Context context, Intent intent) {
	    	String	 receivedata = intent.getStringExtra("result"); // SerialPort  call back data
	    		//Log.e("发送CMD返回数据："  + "  receivedata", receivedata);
	    		if (receivedata != null) {
//	    			if(receivedata.equals("0")){
//	    				Log.e("发送1Cccccccccccc数据："  + "  receivedata", receivedata);
//	    				//cmd_flag=11;
//	    				
//	    			}
//	    			else{
	    			byte []receive_buffer = Tools.HexString2Bytes(receivedata);
	    			switch (cmd_flag) {
	    			case 1: //check PSAM card
						byte [] res= psam.resolveDataFromDevice(receive_buffer);
						if(res != null){
							//activate cpu card succeed, save PSAM_Cardslot
							Editor editor = preferences_sam.edit();
							editor.putString("sam_card", sam_card);
							editor.commit();
							
							PSAM_timer.cancel();
							// read CPU carder
							readCard();		
							
						}else{//check PSAM card
							t++;
							if(t>=0 && t<=2){//check SAM1="01",Ten times
								sam_card="01";
							select_PSAM_CardSlot(sam_card);	
							}else if(t>2 && t<=4){// check SAM2="02",Ten times
								sam_card="02";
								select_PSAM_CardSlot(sam_card);	
							}else if(t>4){//check SAM1 and SAM2 , neither has psam.
								compareCardFail(context,"NONE_PSAM");
								t=0;
							}
							
							
						}
						
						break;
	    			case 11://activate cpu card
	    				if(receivedata.length()>16){
	    				byte []active_buffer = Tools.HexString2Bytes(receivedata);
	    				byte []active_data = psam.resolveDataFromDevice(active_buffer);
	    				if(active_data != null){//activate cpu card succeed,select cpu_DF(The application directory)
	    				cpu_resertTag=true;
	    				cmd_flag=12;
	    				//String cpu_DF = "00A40000022001";cpu_DF =cpu App directory id(=2001)
	    				cpu_send_cmd( cmd_flag, CPU_DF);	
	    				}else{
	    						cpu_resertTag=false;
	    						readCard();	
	    				}
	    				}else{
	    					cpu_resertTag=false;
	    					readCard();	
	    				}  
	    				break;
	    			case 12:// cpu select DF,if returns data is succeed,get RandomNumber
	    				byte [] receiver_buffer_DF = Tools.HexString2Bytes(receivedata);
	    				byte []receiver_data_DF = psam.resolveDataFromDevice(receiver_buffer_DF);
	    				if(receiver_data_DF != null){
	    					String response=Tools.Bytes2HexString(receiver_data_DF, receiver_data_DF.length);
	    					if(!response.equals("")&&response.length()>4){
	    					String command = response.substring(response.length() - 4, response.length());
		    					if(command.equals(succeedNumber)){//into cpu APPdirectory success,last 4 digits are contained 9000
		    					cmd_flag = 13;
		    					//select cpu_DF into APP directory is success。Send commands to get random Numbers.
		    					//String cpu_Random08 = "0084000008";
		    					cpu_send_cmd( cmd_flag, CPU_RANDOM08);	
		    					}else{
		    					//select cpu_DF into APP directory is failed.Because the last 4 digits are not 9000.(9000 It's a sign of success)
		    					compareCardFail(context,"Data_invalid");
		    					}
	    				}else if(!response.equals("")&&response.length()==4){
	    					//response.length()==4  and select cpu_DF File into APP directory is failed。Error code is 6A82 (The file was not found).
	    					compareCardFail(context,"CPU_DF_fail");
	    						
	    					}
	    				}else{//Data failure
	    					readCard();	
	    					//compareCardFail(Setting_Activity.this,"Data_failure");
	    				}
	    				break;
	    			 case 13: 
	    				byte []receiver_buffer_random08 = Tools.HexString2Bytes(receivedata);
	    				byte []receiver_data_random08 = psam.resolveDataFromDevice(receiver_buffer_random08);
	    				if(receiver_data_random08 != null){
	    					String response=Tools.Bytes2HexString(receiver_data_random08, receiver_data_random08.length);
	    					//Log.e("13==" , ""+Tools.Bytes2HexString(receiver_data_random08, receiver_data_random08.length));
	    					if(!response.equals("")&&response.length()>4){
	    						String command = response.substring(response.length() - 4, response.length());
	    						if(command.equals(succeedNumber)){
	    							String cpu_backRandom= response.substring(0, response.length() - 4);
	    						
	    							  Editor editor = preferences.edit();
	    								editor.putString("cpu_backRandom", cpu_backRandom);
	    								editor.commit();	  
	    								//psam Internal authentication
	    								String internalValidation= sam_card+PSAM_INTERNAL+cpu_backRandom;
		    							cmd_flag=15;
		    							psam_send_cmd(cmd_flag,internalValidation);
		    							
	    						}else{
	    							compareCardFail(context,"Data_invalid");
	    						}
	    						}else{
	    							compareCardFail(context,"CPU_RANDOM_fail");	
	    						}
	    				}else{
	    					compareCardFail(context,"Data_failure");
	    				}
	    				break;
	    			case 15: // psam Internal authentication,get response
	    				byte []receiver_buffer_random08mi = Tools.HexString2Bytes(receivedata);
	    				byte []receiver_data_random08mi = psam.resolveDataFromDevice(receiver_buffer_random08mi);
	    				if(receiver_data_random08mi != null){
	    					String commend=Tools.Bytes2HexString(receiver_data_random08mi, receiver_data_random08mi.length);
	    					if(commend.equals("6108")){
	    						//psam Internal encryption random number
	    						cmd_flag=16;
	    						String pasm_getresponse_cmd=  sam_card+PSAM_GET_RESPOND;
	    						psam_send_cmd(cmd_flag,pasm_getresponse_cmd);
	    						}else{//
	    							compareCardFail(context,"Data_invalid");
	    						}
	    					
	    					
	    				}else{
	    					compareCardFail(context,"Data_failure");
	    					
	    				}
	    				break;
	    			case 16: // if psam Internal encryption random number succeed,after CPU external authentication random number 
						cmd_flag=17;
	    				byte []internalValidation_buffer = Tools.HexString2Bytes(receivedata);
	    				byte []internalValidation_data= psam.resolveDataFromDevice(internalValidation_buffer);
	    				if(internalValidation_data != null){
	    					String psam_encrypt_data=Tools.Bytes2HexString(internalValidation_data, internalValidation_data.length);
	    					//Log.e("16.广播接收数据：psam内部加密随机数ok" , psam_encrypt_data);
	    					if(psam_encrypt_data!=null&&!psam_encrypt_data.equals("")&&psam_encrypt_data.length()>16){
	    						   String command = psam_encrypt_data.substring(psam_encrypt_data.length() - 4, psam_encrypt_data.length());
	    						if(command.equals(succeedNumber)){
	    							 String encrypt_data= psam_encrypt_data.substring(0, psam_encrypt_data.length() - 4);
	    							//cpu External certification 
	    							cmd_flag=17;
	    							String externalCertification=CPU_EXITERNAL+encrypt_data;
	    							cpu_send_cmd(cmd_flag,externalCertification);
	    						}else{
	    							compareCardFail(context,"Data_invalid");
	    						}
	    					}else{
	    						//Psam internal encryption random number failed.
		    					compareCardFail(context,"encrypting_fail");
	    							
	    					}	
	    					
	    				}else{
	    					compareCardFail(context,"Data_failure");
	    					
	    				}
	    				break;
	    			case 17: 
	    				byte [] external_back = Tools.HexString2Bytes(receivedata);
	    				byte []external_back_data= psam.resolveDataFromDevice(external_back);
	    				if(external_back_data != null){
	    					String back_Number=Tools.Bytes2HexString(external_back_data, external_back_data.length);
	    					//Log.e("17.外部认证OK==" , ""+back_Number);
	    					if(back_Number!=null&&!back_Number.equals("")&&back_Number.equals(succeedNumber)){
	    						//External certification returns 9000,read binary. =="00b0810008"
	    						 cmd_flag=18;
	    						cpu_send_cmd(cmd_flag,CPU_READ_BINARY); 	 
	    					}else{
	    						compareCardFail(context,"Data_invalid");
	    					}
	    				
	    				}else{
	    					compareCardFail(context,"Data_failure");
	    					
	    				}
	    				break;
	    			case 18: 
	    				byte [] cpu_back = Tools.HexString2Bytes(receivedata);
	    				byte []cpu_back_data= psam.resolveDataFromDevice(cpu_back);
	    				if(cpu_back_data != null){
	    					String card_Number_data=Tools.Bytes2HexString(cpu_back_data, cpu_back_data.length);
	    					//Log.e("18.外部认证OK==" , ""+card_Number_data);
	    					if(card_Number_data!=null&&!card_Number_data.equals("")&&card_Number_data.length()>4){
	    						   String command = card_Number_data.substring(card_Number_data.length() - 4, card_Number_data.length());
	    						if(command.equals(succeedNumber)){
	    							//read binary returns data
	    							 String card_Number= card_Number_data.substring(0, card_Number_data.length() - 4);
	    							 byte[] card_NumberByte = Tools.HexString2Bytes(card_Number);
	    								int cardNumber=Tools.bytesToInt(card_NumberByte,0);
	    							Utils.playerVoice(WelcomeActivity.this, 6);
	    							//		Log.e("18.获取卡号==",""+cardNumber);
	    						        comperCarder(cardNumber);
	    						}else{
	    							compareCardFail(context,"Data_invalid");
	    						}
	    					}else{
	    						compareCardFail(context,"Data_invalid");
	    					}
	    				
	    				}else{
	    					compareCardFail(context,"Data_failure");
	    				}
	    				break;
	    			}
	    		//}
	    	 }
	    	}
		
			private void psam_send_cmd(int cmd_flag, String internalValidation) {
	    		//Intent sendToservice = new Intent(context,DeviceService.class);  //用于发送指令
	    		byte [] cmd = null;  
	    		cmd = psam.sam_send_cmd(Tools.HexString2Bytes(internalValidation));
	    		sendToservice.putExtra("cmd", cmd); 
	    		sendToservice.putExtra("activity", activity); 
	    		context.startService(sendToservice); 
	    		
	    	}
	    	private void cpu_send_cmd(int cmd_flag, String command) {
	    		//Intent sendToservice = new Intent(context,DeviceService.class); 
	    		byte [] cmd = null;  
	    		cmd  = psam.ucpu_send_cmd(Tools.HexString2Bytes(command));
	    		sendToservice.putExtra("cmd", cmd);  
	    		sendToservice.putExtra("activity", activity); 
	    		context.startService(sendToservice); 
	    	
	    	}
	    	 private void comperCarder(int carderNumber) {
	         	String  UID = String.valueOf(carderNumber);
	         	if(!UID.equals("")){
	         		CollectiveCardInfo	 collectiveCardInfo=FileDataHelp.collectiveCard(MyApplication.COLLECTIVITY_INFO_FILE,UID );
	         	    if(collectiveCardInfo!=null){
	         	    	CollectiveCardAuthorizationDate   dateInfo=FileDataHelp.collectiveCardDate(MyApplication.COLLECTIVITY_AUTH9_FILE,collectiveCardInfo.getCollective_carder_id());
	         	    	List<CollectiveCardAuthorizationTime>  timeList=FileDataHelp.collectiveCardTime(MyApplication.COLLECTIVITY_AUTH10_FILE,collectiveCardInfo.getCollective_carder_id()); 	  
	         	    	if(collectiveCardInfo.getCarderNumber()!=null&&dateInfo.getDate_start()!=null&&dateInfo.getDate_end()!=null){
	            	    	
	         	    		collectiveCardInfo.setCollectiveDateInfo(dateInfo);
	        	    		collectiveCardInfo.setCollectiveTimeInfo(timeList);
	        	    		compareCarder.collectiveCarder(context,collectiveCardInfo,UID);
	        	    	
	         	    	}else{
	           	    	 compareCarder.personCarder( context,UID);	
	           	    	}
	         	    	
	         	    	} else{
	                     compareCarder.personCarder( context,UID);
	                }
	         	
	         	}else{
	         		compareCardFail(context,"");
	         	}
	 	    	
	 	    }  
	    public  void compareCardFail(Context activity, String carderId) {
	        Intent intent = new Intent();
	        intent.putExtra("uid", carderId);
	        intent.setClass(activity, UnknownCarderActivity.class);//UnknownCarderActivity
	        activity.startActivity(intent);
	    }
	    }	
	    
	  
	}
