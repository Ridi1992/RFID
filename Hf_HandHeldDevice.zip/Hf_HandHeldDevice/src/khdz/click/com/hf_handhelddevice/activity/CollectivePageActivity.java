package khdz.click.com.hf_handhelddevice.activity;

import static khdz.click.com.hf_handhelddevice.activity.WelcomeActivity.FLAG_HOMEKEY_DISPATCHED;

import java.util.ArrayList;
import java.util.List;

import khdz.click.com.hf_handhelddevice.FileDataHelp;
import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.R;
import khdz.click.com.hf_handhelddevice.R.id;
import khdz.click.com.hf_handhelddevice.R.layout;
import khdz.click.com.hf_handhelddevice.adapter.CollectivePagerAdapter;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardInfo;
import khdz.click.com.hf_handhelddevice.data.CollectivePersonInfo;
import khdz.click.com.hf_handhelddevice.data.PersonInfo;
import android.app.Activity;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

public class CollectivePageActivity extends Activity {
	private ViewPager mViewPager;
	private ArrayList<View> mViewList;
	private List<PersonInfo> peopleList;
	private String cardNumber;
	private  CollectiveCardInfo	 collectiveCardInfo;
	private CollectivePagerAdapter wadapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		  requestWindowFeature(Window.FEATURE_NO_TITLE);
	      getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
	      this.getWindow().setFlags(FLAG_HOMEKEY_DISPATCHED, FLAG_HOMEKEY_DISPATCHED);//Shielding home button
		 setContentView(R.layout.activity_gallery);
		cardNumber=	getIntent().getStringExtra("cardNumber");
		collectiveCardInfo=FileDataHelp.collectiveCard(MyApplication.COLLECTIVITY_INFO_FILE,cardNumber );
		initView();
		
	}
	private void initView() {
		mViewPager = (ViewPager) findViewById(R.id.vp);
		mViewList = new ArrayList<View>();
		peopleList= new ArrayList<PersonInfo>();
		LayoutInflater inflater = getLayoutInflater();
		if(collectiveCardInfo!=null&&collectiveCardInfo.getCollectivePersonInfo().size()>0){
			for(CollectivePersonInfo info: collectiveCardInfo.getCollectivePersonInfo()){
				
				PersonInfo	 personInfo= FileDataHelp.compareCard(MyApplication.PERSIN_INFO_FILE,info.getPerson_sn());
				peopleList.add(personInfo); 
				View view1 = inflater.inflate(R.layout.activity_collection_personal_detail, null);
				mViewList.add(view1);
			}
		}else{
			
		}
		
		wadapter=new CollectivePagerAdapter(mViewList,peopleList);
		mViewPager.setAdapter(wadapter);
	}
	


}
