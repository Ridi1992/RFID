package khdz.click.com.hf_handhelddevice.activity;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import com.android.rfid.PSAM;
import com.android.rfid.Tools;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import khdz.click.com.hf_handhelddevice.CompareCarder;
import khdz.click.com.hf_handhelddevice.FileDataHelp;
import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.R;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardAuthorizationDate;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardAuthorizationTime;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardInfo;
import khdz.click.com.hf_handhelddevice.data.PersonInfo;
import khdz.click.com.hf_handhelddevice.service.DeviceService;
import khdz.click.com.hf_handhelddevice.tools.Utils;

import static khdz.click.com.hf_handhelddevice.activity.WelcomeActivity.FLAG_HOMEKEY_DISPATCHED;

public class CollectivePersonalDetail extends Activity {
	private TextView title;
	private ImageView photo;
	private TextView name;
	private TextView departmentName;
	private TextView principalName;
	private TextView idCard;
	private TextView time;
    private String person_sn;
    private PersonInfo info;
    
  //SerialPort
    public   Context context;
  	private  PSAM psam;						
  	private  MyBroadcast myBroadcast;			
  	public  int cmd_flag = 0;
  	public   String sam_card="01";				//Ĭ��SAM1��Ϊ01��SAM2��Ϊ02���벻Ҫ����	
  	public   String activity = "khdz.click.com.hf_handhelddevice.activity.CollectionPersonalDetail";
  	public  boolean cpu_resertTag=false;
  	public String succeedNumber="9000";
  	//SerialPort  CMD
  	public String CPU_DF="00A40000022001";
  	public String CPU_RANDOM08 = "0084000008";
  	public String PSAM_GET_RESPOND="00c0000008";//08 ��ȡ8�ֽ�
  	public String PSAM_INTERNAL="0088000108";
  	public String CPU_EXITERNAL="0082000008";
  	public String CPU_READ_BINARY="00b0810008";//���ļ���������ȡ����������81�����λ����1.
  	public Timer PSAM_timer,timer;
  	private    CompareCarder compareCarder=null;
	public Intent sendToservice ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.getWindow().setFlags(FLAG_HOMEKEY_DISPATCHED, FLAG_HOMEKEY_DISPATCHED);//Shielding home button
        setContentView(R.layout.activity_collection_personal_detail);
        context=this;
        initView();
        person_sn = getIntent().getStringExtra("person_sn");
        if(person_sn!=null&&!person_sn.equals("")){
        info=   FileDataHelp.compareCard(MyApplication.PERSIN_INFO_FILE,person_sn);
        }
        if (info != null) {
            initData(info);
        }
    }
    private void initView() {
    	title=(TextView)findViewById(R.id.title);
    	photo=(ImageView)findViewById(R.id.photo);
    	name=(TextView)findViewById(R.id.name);
    	departmentName=(TextView)findViewById(R.id.department_name);
    	principalName=(TextView)findViewById(R.id.principal_name);
    	idCard=(TextView)findViewById(R.id.id_card);	
    	time=(TextView)findViewById(R.id.time);	
    	title.setText(R.string.collectionCarder);
	}
	private void initData(PersonInfo info) {
        String wname = MyApplication.DeCode(info.getName());
        name.setText(wname);
        idCard.setText(info.getId_card());
        departmentName.setText(info.getPrincipal_name());
        principalName.setText(info.getDepart_name());
        time.setText(Utils.getDateTime());
        String path = MyApplication.getFileNameIsPhoto(info.getPerson_iris_sn());
        if (path.equals("")) {
        	photo.setBackgroundResource(R.drawable.hotelimage);
        }
        Bitmap btm = Utils.getLocalBitmap(path);
        if (btm != null) {
        	photo.setImageBitmap(btm);
        }
    }
	
	
	
	 /***
		 * read carder
	     * must be implemented
	     */
	    @Override
	    protected void onResume() {
	    	super.onResume();
	    	
	    	psam = new PSAM(); // Used to invoke protocol wrapping commands
	        compareCarder=new CompareCarder(context);
	    	myBroadcast = new MyBroadcast();
	    	IntentFilter filter = new IntentFilter();
	    	filter.addAction(activity);
	    	registerReceiver(myBroadcast, filter); // Register broadcast receiver, receive serial port to return data
	       //The timer loop select PSAMCardSlot,check PSAMcarder is in SAM1(01) OR SAM2(02) or  psam is null.
	   	   sendToservice = new Intent(context,DeviceService.class);  //���ڷ���ָ��
	       // get SAM_CardSlot
           SharedPreferences preferences = getSharedPreferences("SAM_CardSlot", Context.MODE_PRIVATE);
           sam_card=preferences.getString("sam_card", "02");
    	 
	   	 PSAM_timer = new Timer();
	    	PSAM_timer.schedule(new TimerTask() {
	            @Override
	            public void run() {
	            synchronized(this){//this is very importance.
	            select_PSAM_CardSlot(sam_card);
	            	} 
	            }
	        }, 1000 * 2);

	    }	 
	   
		@Override
	    protected void onPause() {
			super.onPause();
				 cmd_flag = 0;
				 unregisterReceiver(myBroadcast); 
				 stopService(sendToservice);
	    }	
	    private void readCard() {  
	    //	Intent sendToservice = new Intent(context,DeviceService.class);  //���ڷ���ָ��
	    	byte [] cmd = null;  
	    	cmd_flag = 11;
	    	cmd = psam.ucpu_open();
	    	if(cmd != null ){
	    		sendToservice.putExtra("cmd", cmd); 
	    		context.startService(sendToservice); 
	    		}else{
	    		}	    	
	    }
	    public  void select_PSAM_CardSlot(String sam_card) {  
	    //	Intent sendToservice = new Intent(context,DeviceService.class);  //���ڷ���ָ��
	    	byte [] cmd = null;  
	    	cmd_flag = 1;
			byte[] get_sam_card = Tools.HexString2Bytes(sam_card);
			cmd = psam.sam_reset(get_sam_card);
			if(cmd != null ){
	    		sendToservice.putExtra("cmd", cmd); 
	    		sendToservice.putExtra("activity", activity); 
	    		context.startService(sendToservice); 
	    		}else{
	    		//Log.e("���ã�", "send circulationToReadCard");
	    		}	    	
	    }
	    /**
	     * Broadcast receiver, used to receive the data returned by the service, and update the UI
	     * @author Administrator
	     *
	     */
	    private class MyBroadcast extends BroadcastReceiver{
	    	 SharedPreferences preferences = getSharedPreferences("cmd_backData", Context.MODE_PRIVATE);
	    	 SharedPreferences preferences_sam = getSharedPreferences("SAM_CardSlot", Context.MODE_PRIVATE);
	    	 int t=0;
	    	 @Override
	    	public void onReceive(Context context, Intent intent) {
	    	String	 receivedata = intent.getStringExtra("result"); // SerialPort  call back data
	    		//Log.e("����CMD�������ݣ�"  + "  receivedata", receivedata);
	    		if (receivedata != null) {
	    			byte []receive_buffer = Tools.HexString2Bytes(receivedata);
	    			switch (cmd_flag) {
	    			case 1: //check PSAM card
						byte [] res= psam.resolveDataFromDevice(receive_buffer);
						if(res != null){
							//activate cpu card succeed, save PSAM_Cardslot
							Editor editor = preferences_sam.edit();
							editor.putString("sam_card", sam_card);
							editor.commit();
							PSAM_timer.cancel();
							// read CPU carder
							readCard();		
							
						}else{//check PSAM card
							t++;
							if(t>=0 && t<=2){//check SAM1="01",Ten times
								sam_card="01";
							select_PSAM_CardSlot(sam_card);	
							}else if(t>2 && t<=4){// check SAM2="02",Ten times
								sam_card="02";
								select_PSAM_CardSlot(sam_card);	
							}else if(t>4){//check SAM1 and SAM2 , neither has psam.
								compareCardFail(context,"NONE_PSAM");
								t=0;
							}
							
							
						}
						
						break;
	    			case 11://activate cpu card
	    				if(receivedata.length()>16){
	    				byte []active_buffer = Tools.HexString2Bytes(receivedata);
	    				byte []active_data = psam.resolveDataFromDevice(active_buffer);
	    				if(active_data != null){//activate cpu card succeed,select cpu_DF(The application directory)
	    				cpu_resertTag=true;
	    				cmd_flag=12;
	    				//String cpu_DF = "00A40000022001";cpu_DF =cpu App directory id(=2001)
	    				cpu_send_cmd( cmd_flag, CPU_DF);	
	    				}else{
	    						cpu_resertTag=false;
	    						readCard();	
	    				}
	    				}else{
	    					cpu_resertTag=false;
	    					readCard();	
	    				}  
	    				break;
	    			case 12:// cpu select DF,if returns data is succeed,get RandomNumber
	    				byte [] receiver_buffer_DF = Tools.HexString2Bytes(receivedata);
	    				byte []receiver_data_DF = psam.resolveDataFromDevice(receiver_buffer_DF);
	    				if(receiver_data_DF != null){
	    					String response=Tools.Bytes2HexString(receiver_data_DF, receiver_data_DF.length);
	    					if(!response.equals("")&&response.length()>4){
	    					String command = response.substring(response.length() - 4, response.length());
		    					if(command.equals(succeedNumber)){//into cpu APPdirectory success,last 4 digits are contained 9000
		    					cmd_flag = 13;
		    					//select cpu_DF into APP directory is success��Send commands to get random Numbers.
		    					//String cpu_Random08 = "0084000008";
		    					cpu_send_cmd( cmd_flag, CPU_RANDOM08);	
		    					}else{
		    					//select cpu_DF into APP directory is failed.Because the last 4 digits are not 9000.(9000 It's a sign of success)
		    					compareCardFail(context,"Data_invalid");
		    					}
	    				}else if(!response.equals("")&&response.length()==4){
	    					//response.length()==4  and select cpu_DF File into APP directory is failed��Error code is 6A82 (The file was not found).
	    					compareCardFail(context,"CPU_DF_fail");
	    						
	    					}
	    				}else{//Data failure
	    					readCard();	
	    					//compareCardFail(Setting_Activity.this,"Data_failure");
	    				}
	    				break;
	    			 case 13: 
	    				byte []receiver_buffer_random08 = Tools.HexString2Bytes(receivedata);
	    				byte []receiver_data_random08 = psam.resolveDataFromDevice(receiver_buffer_random08);
	    				if(receiver_data_random08 != null){
	    					String response=Tools.Bytes2HexString(receiver_data_random08, receiver_data_random08.length);
	    					//Log.e("13==" , ""+Tools.Bytes2HexString(receiver_data_random08, receiver_data_random08.length));
	    					if(!response.equals("")&&response.length()>4){
	    						String command = response.substring(response.length() - 4, response.length());
	    						if(command.equals(succeedNumber)){
	    							String cpu_backRandom= response.substring(0, response.length() - 4);
	    						
	    							  Editor editor = preferences.edit();
	    								editor.putString("cpu_backRandom", cpu_backRandom);
	    								editor.commit();	  
	    								//psam Internal authentication
	    								String internalValidation= sam_card+PSAM_INTERNAL+cpu_backRandom;
		    							cmd_flag=15;
		    							psam_send_cmd(cmd_flag,internalValidation);
		    							
	    						}else{
	    							compareCardFail(context,"Data_invalid");
	    						}
	    						}else{
	    							compareCardFail(context,"CPU_RANDOM_fail");	
	    						}
	    				}else{
	    					compareCardFail(context,"Data_failure");
	    				}
	    				break;
	    			case 15: // psam Internal authentication,get response
	    				byte []receiver_buffer_random08mi = Tools.HexString2Bytes(receivedata);
	    				byte []receiver_data_random08mi = psam.resolveDataFromDevice(receiver_buffer_random08mi);
	    				if(receiver_data_random08mi != null){
	    					String commend=Tools.Bytes2HexString(receiver_data_random08mi, receiver_data_random08mi.length);
	    					if(commend.equals("6108")){
	    						//psam Internal encryption random number
	    						cmd_flag=16;
	    						String pasm_getresponse_cmd=  sam_card+PSAM_GET_RESPOND;
	    						psam_send_cmd(cmd_flag,pasm_getresponse_cmd);
	    						}else{//
	    							compareCardFail(context,"Data_invalid");
	    						}
	    					
	    					
	    				}else{
	    					compareCardFail(context,"Data_failure");
	    					
	    				}
	    				break;
	    			case 16: // if psam Internal encryption random number succeed,after CPU external authentication random number 
						cmd_flag=17;
	    				byte []internalValidation_buffer = Tools.HexString2Bytes(receivedata);
	    				byte []internalValidation_data= psam.resolveDataFromDevice(internalValidation_buffer);
	    				if(internalValidation_data != null){
	    					String psam_encrypt_data=Tools.Bytes2HexString(internalValidation_data, internalValidation_data.length);
	    					//Log.e("16.�㲥�������ݣ�psam�ڲ����������ok" , psam_encrypt_data);
	    					if(psam_encrypt_data!=null&&!psam_encrypt_data.equals("")&&psam_encrypt_data.length()>16){
	    						   String command = psam_encrypt_data.substring(psam_encrypt_data.length() - 4, psam_encrypt_data.length());
	    						if(command.equals(succeedNumber)){
	    							 String encrypt_data= psam_encrypt_data.substring(0, psam_encrypt_data.length() - 4);
	    							//cpu External certification 
	    							cmd_flag=17;
	    							String externalCertification=CPU_EXITERNAL+encrypt_data;
	    							cpu_send_cmd(cmd_flag,externalCertification);
	    						}else{
	    							compareCardFail(context,"Data_invalid");
	    						}
	    					}else{
	    						//Psam internal encryption random number failed.
		    					compareCardFail(context,"encrypting_fail");
	    							
	    					}	
	    					
	    				}else{
	    					compareCardFail(context,"Data_failure");
	    					
	    				}
	    				break;
	    			case 17: 
	    				byte [] external_back = Tools.HexString2Bytes(receivedata);
	    				byte []external_back_data= psam.resolveDataFromDevice(external_back);
	    				if(external_back_data != null){
	    					String back_Number=Tools.Bytes2HexString(external_back_data, external_back_data.length);
	    					//Log.e("17.�ⲿ��֤OK==" , ""+back_Number);
	    					if(back_Number!=null&&!back_Number.equals("")&&back_Number.equals(succeedNumber)){
	    						//External certification returns 9000,read binary. =="00b0810008"
	    						 cmd_flag=18;
	    						cpu_send_cmd(cmd_flag,CPU_READ_BINARY); 	 
	    					}else{
	    						compareCardFail(context,"Data_invalid");
	    					}
	    				
	    				}else{
	    					compareCardFail(context,"Data_failure");
	    					
	    				}
	    				break;
	    			case 18: 
	    				byte [] cpu_back = Tools.HexString2Bytes(receivedata);
	    				byte []cpu_back_data= psam.resolveDataFromDevice(cpu_back);
	    				if(cpu_back_data != null){
	    					String card_Number_data=Tools.Bytes2HexString(cpu_back_data, cpu_back_data.length);
	    					//Log.e("18.�ⲿ��֤OK==" , ""+card_Number_data);
	    					if(card_Number_data!=null&&!card_Number_data.equals("")&&card_Number_data.length()>4){
	    						   String command = card_Number_data.substring(card_Number_data.length() - 4, card_Number_data.length());
	    						if(command.equals(succeedNumber)){
	    							//read binary returns data
	    							 String card_Number= card_Number_data.substring(0, card_Number_data.length() - 4);
	    							 byte[] card_NumberByte = Tools.HexString2Bytes(card_Number);
	    								int cardNumber=Tools.bytesToInt(card_NumberByte,0);
	    								//Log.e("18.��ȡ����==",""+cardNumber);
	    								Utils.playerVoice(CollectivePersonalDetail.this, 6);
	    								comperCarder(cardNumber);
	    						}else{
	    							compareCardFail(context,"Data_invalid");
	    						}
	    					}else{
	    						compareCardFail(context,"Data_invalid");
	    					}
	    				
	    				}else{
	    					compareCardFail(context,"Data_failure");
	    				}
	    				break;
	    			}
	    		}
	    		
	    	}
		
			private void psam_send_cmd(int cmd_flag, String internalValidation) {
	    	//	Intent sendToservice = new Intent(context,DeviceService.class);  //���ڷ���ָ��
	    		byte [] cmd = null;  
	    		cmd = psam.sam_send_cmd(Tools.HexString2Bytes(internalValidation));
	    		sendToservice.putExtra("cmd", cmd); 
	    		sendToservice.putExtra("activity", activity); 
	    		context.startService(sendToservice); 
	    		
	    	}
	    	private void cpu_send_cmd(int cmd_flag, String command) {
	    	//	Intent sendToservice = new Intent(context,DeviceService.class); 
	    		byte [] cmd = null;  
	    		cmd  = psam.ucpu_send_cmd(Tools.HexString2Bytes(command));
	    		sendToservice.putExtra("cmd", cmd);  
	    		sendToservice.putExtra("activity", activity); 
	    		context.startService(sendToservice); 
	    	
	    	}
	    	 private void comperCarder(int carderNumber) {
	         	String  UID = String.valueOf(carderNumber);
	         	if(!UID.equals("")){
	         		CollectiveCardInfo	 collectiveCardInfo=FileDataHelp.collectiveCard(MyApplication.COLLECTIVITY_INFO_FILE,UID );
	         	    if(collectiveCardInfo!=null){
	         	    	CollectiveCardAuthorizationDate   dateInfo=FileDataHelp.collectiveCardDate(MyApplication.COLLECTIVITY_AUTH9_FILE,collectiveCardInfo.getCollective_carder_id());
	         	    	List<CollectiveCardAuthorizationTime>  timeList=FileDataHelp.collectiveCardTime(MyApplication.COLLECTIVITY_AUTH10_FILE,collectiveCardInfo.getCollective_carder_id()); 	  
	         	    	if(collectiveCardInfo.getCarderNumber()!=null&&dateInfo.getDate_start()!=null&&dateInfo.getDate_end()!=null){
	            	    	
	         	    		collectiveCardInfo.setCollectiveDateInfo(dateInfo);
	        	    		collectiveCardInfo.setCollectiveTimeInfo(timeList);
	        	    		compareCarder.collectiveCarder(context,collectiveCardInfo,UID);
	        	    	
	         	    	}else{
	           	    	 compareCarder.personCarder( context,UID);	
	           	    	}
	         	    	
	         	    	} else{
	                     compareCarder.personCarder( context,UID);
	                }
	         	
	         	}else{
	         		compareCardFail(context,"");
	         	}
	 	    	
	 	    }  
	    public  void compareCardFail(Context activity, String carderId) {
	        Intent intent = new Intent();
	        intent.putExtra("uid", carderId);
	        intent.setClass(activity, UnknownCarderActivity.class);//UnknownCarderActivity
	        activity.startActivity(intent);
	    }
	    }	
	
}
