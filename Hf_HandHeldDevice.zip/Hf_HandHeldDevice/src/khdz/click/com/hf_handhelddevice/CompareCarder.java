package khdz.click.com.hf_handhelddevice;

import java.util.Date;
import java.util.List;

import khdz.click.com.hf_handhelddevice.activity.ShowCarderInfo_Activity;
import khdz.click.com.hf_handhelddevice.activity.ShowCollectiveInfo_Activity;
import khdz.click.com.hf_handhelddevice.activity.UnknownCarderActivity;
import khdz.click.com.hf_handhelddevice.activity.WelcomeActivity;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardAuthorizationDate;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardAuthorizationTime;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardInfo;
import khdz.click.com.hf_handhelddevice.data.PersonAuthorizationTime;
import khdz.click.com.hf_handhelddevice.data.PersonAuthorizationDate;
import khdz.click.com.hf_handhelddevice.data.PersonDeviceInfo;
import khdz.click.com.hf_handhelddevice.data.PersonInfo;
import khdz.click.com.hf_handhelddevice.tools.Timetool;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/**
 * Created by Administrator on 2017/9/22.
 */

public class CompareCarder {
private Context context;

    public CompareCarder(Context context) {
        this.context=context;
    }
    //***************************************Comppare  PersonageCard
    public  void personCarder(Context activity, String UID) {
        PersonInfo nativeInfobean = FileDataHelp.compareCard(MyApplication.PERSIN_INFO_FILE, UID);
        if (nativeInfobean != null && nativeInfobean.getPerson_sn() != null && !nativeInfobean.getId_card().equals("") && nativeInfobean.getId_card().equals(UID)) {
                            PersonDeviceInfo deviceInfo = FileDataHelp.compareCardPersonAuthDevice(MyApplication.PERSIN_AUTH3_FILE, nativeInfobean.getPerson_sn());
                            if (deviceInfo != null && deviceInfo.getPerson_sn() != null && !deviceInfo.getPerson_sn().equals("") && deviceInfo.getPerson_sn().equals(nativeInfobean.getPerson_sn())) {
                                PersonAuthorizationDate authDate = FileDataHelp.compareCardPersonAuthDeviceData(MyApplication.PERSIN_AUTH4_FILE, nativeInfobean.getPerson_sn());
                                String todayDate = Timetool.getDateTime();//get Today Date to compare antu Date
                                if (authDate != null && !authDate.getDate_from().equals("") && !authDate.getDate_to().equals("")) {
                                	
                                        if (compareDate(authDate, todayDate)) {//contains today,so compareTime
                                        compareTime(UID,nativeInfobean, authDate, todayDate);
                                        } else {//date is not exit
                                        compareCardFail(activity,UID);
                                        }
                                } else {//devicesInfo is no from date,no to date,so compare weeks and time
                                 compareTime(UID,nativeInfobean, authDate, todayDate);
                                }


                            } else {// PersonDeviceInfo.getPerson_sn()==null,not compared devices info,comparison fails!
                                compareCardFail(activity,UID);
                            }

                        } else {//PersonInfo not find carderNumber,comparison fails!
                            compareCardFail(activity,UID);
                        }
    }

    public  void compareCardFail(Context activity, String carderId) {
//        WelcomeActivity.IS_DOWHILE_FLAG = false;//stop ReadCarder
        Intent intent = new Intent();
        intent.putExtra("uid", carderId);
        intent.setClass(activity, UnknownCarderActivity.class);//UnknownCarderActivity
        activity.startActivity(intent);
    }
    public boolean compareDate(PersonAuthorizationDate authDate, String todayDate) {
        boolean flag = false;
        String[] todayDateArray = null;//todayDate.split(" ");
        if(authDate.getDate_from().contains("-")&&authDate.getDate_to().contains("-")){
            todayDateArray= Timetool.getDateTimeCross().split(" ");
            long nowDate = Timetool.getlongTimeCross(todayDateArray[0]);
            long fromDate = Timetool.getlongTimeCross(authDate.getDate_from());
            long toDate = Timetool.getlongTimeCross(authDate.getDate_to());
            if (nowDate >= fromDate && nowDate <= toDate) {
                flag = true;
            } else {
                flag = false;
            }


        }else if(authDate.getDate_from().contains("/")&&authDate.getDate_to().contains("/")){
            todayDateArray =todayDate.split(" ");
            long nowDate = new Date(todayDateArray[0]).getTime();
            long fromDate = new Date(authDate.getDate_from()).getTime();
            long toDate = new Date(authDate.getDate_to()).getTime();
            if (nowDate >= fromDate && nowDate <= toDate) {
                flag = true;
            } else {
                flag = false;
            }
        }
        return flag;
    }
    public void compareTime(String UID,PersonInfo nativeInfobean, PersonAuthorizationDate authDate, String todayDate) {
        String[] todayDateArray = todayDate.split(" ");
        List<PersonAuthorizationTime> authTimeInfoList = FileDataHelp.compareCardPersonAuthDeviceTime(MyApplication.PERSIN_AUTH5_FILE, authDate.getPerson_sn()); //People auth time
        if (authTimeInfoList!=null&&authTimeInfoList.size() > 0) {
            for (int i = 0; i <= authTimeInfoList.size(); i++) {// if i==1 IndexOutOfBoundsException
                PersonAuthorizationTime authTimeInfo = authTimeInfoList.get(i);
                if (authTimeInfo != null && !authTimeInfo.getWeek_info().equals("")) {
                    String time_start = authTimeInfo.getTime_start();
                    String time_end = authTimeInfo.getTime_end();
                    String w = todayDateArray[2].substring(1, todayDateArray[2].length());
                    String a = authTimeInfo.getWeek_info();

//***************************************Compare Week_info, whether today is included

                    if (a.contains(w)) {
                        String[] time_startArray = time_start.split(":");
                        String[] time_endArray = time_end.split(":");
                        String[] now_timeArray =  todayDateArray[1].split(":");
                        int startHour = Integer.parseInt(time_startArray[0]);
                        int endHour = Integer.parseInt(time_endArray[0]);
                        int nowHour = Integer.parseInt(now_timeArray[0]);
                        int startMinutes = Integer.parseInt(time_startArray[1]);
                        int endMinutes = Integer.parseInt(time_endArray[1]);
                        int nowMinutes = Integer.parseInt(now_timeArray[1]);
                        if (nowHour >= startHour && nowHour <= endHour) {
                            if (nowMinutes >= startMinutes && nowMinutes <= endMinutes) {
//                                WelcomeActivity.IS_DOWHILE_FLAG = false;//stop ReadCarder
                                Intent intent = new Intent();
                                intent.putExtra("bean", nativeInfobean);
                                intent.setClass(context, ShowCarderInfo_Activity.class);
                                context.startActivity(intent);
                                break;
                            } else {// Minutes is not contains
                                compareCardFail(context,UID);
                                break;
                            }
                        } else {//hour is not right  remove
                            authTimeInfoList.remove(i);
                            i--;
                            if(authTimeInfoList.size()>0){continue;}
                            if(authTimeInfoList.size()==0){compareCardFail(context,UID);break;}
                        }

                    } else {//Week_info is not contains now weeks,remove!
                        authTimeInfoList.remove(i);
                        i--;
                        if(authTimeInfoList.size()>0){//After removal, the List.size()> 0,Continue  the next record!
                            continue;}
                        if(authTimeInfoList.size()==0){//After removal, the List.size() is 0,  comparison fails!
                            compareCardFail(context,UID);break;}
                    }


                }//authTimeInfo.getWeek_info()==null/equals("")

            }//for
        }
    }
//***************************************Comppare  CollectiveCard
    public void collectiveCarder(Context activity, CollectiveCardInfo collectiveCardInfo, String UID) {
    	CollectiveCardAuthorizationDate collectiveDate=   collectiveCardInfo.getCollectiveDateInfo();
        String todayDate =Timetool.getDateTime();//get Today Date to compare antu Date

        if (collectiveDate != null && !collectiveDate.getDate_start().equals("") && !collectiveDate.getDate_end().equals("")) {
        if (compareCollectiveCardDate(collectiveDate, todayDate)) {//contains today,so compareTime
        compareCollectiveCardTime(activity,UID,collectiveCardInfo, todayDate);
        } else {//date is not exit
        compareCardFail(activity,UID);
        }
       } else {//devicesInfo is no from date,no to date,so compare weeks and time
       compareCollectiveCardTime(activity,UID,collectiveCardInfo, todayDate);
       }
    }
    private void compareCollectiveCardTime(Context activity,String UID,CollectiveCardInfo collectiveCardInfo, String todayDate) {
        List<CollectiveCardAuthorizationTime> authTimeInfoList=collectiveCardInfo.getCollectiveTimeInfo();
        String[] todayDateArray = todayDate.split(" ");
        
        
        if (authTimeInfoList!=null&&authTimeInfoList.size() > 0) {
            for (int i = 0; i <= authTimeInfoList.size(); i++) {// if i==1 IndexOutOfBoundsException
            	CollectiveCardAuthorizationTime authTimeInfo = authTimeInfoList.get(i);
                if (authTimeInfo != null && !authTimeInfo.getWeek_info().equals("")) {
                    String time_start = authTimeInfo.getStart_time();
                    String time_end = authTimeInfo.getEnd_time();
                    String w = todayDateArray[2].substring(1, todayDateArray[2].length());
                    String a = authTimeInfo.getWeek_info();
                    if (a.contains(w)) {
                        String[] time_startArray = time_start.split(":");
                        String[] time_endArray = time_end.split(":");
                        String[] now_timeArray =  todayDateArray[1].split(":");
                        int startHour = Integer.parseInt(time_startArray[0]);
                        int endHour = Integer.parseInt(time_endArray[0]);
                        int nowHour = Integer.parseInt(now_timeArray[0]);
                        int startMinutes = Integer.parseInt(time_startArray[1]);
                        int endMinutes = Integer.parseInt(time_endArray[1]);
                        int nowMinutes = Integer.parseInt(now_timeArray[1]);
                        if (nowHour >= startHour && nowHour <= endHour) {
                            if (nowMinutes >= startMinutes && nowMinutes <= endMinutes) {
//                                WelcomeActivity.IS_DOWHILE_FLAG = false;//stop ReadCarder
                                Intent intent = new Intent();
                                Bundle bundle = new Bundle();
                                bundle.putSerializable("CollectiveCardInfo", collectiveCardInfo);
                                bundle.putString("PageTag", "WelcomeActivity");
                                
                                intent.putExtras(bundle);
                                //   intent.putExtra("personList", (Serializable) authpersonList);
                                intent.setClass(activity, ShowCollectiveInfo_Activity.class);
                                activity.startActivity(intent);
                                break;
                            } else {// Minutes is not contains
                               compareCardFail(activity,UID);
                                break;
                            }
                        } else {//hour is not right  remove
                            authTimeInfoList.remove(i);
                            i--;
                            if(authTimeInfoList.size()>0){continue;}
                            if(authTimeInfoList.size()==0){
                               compareCardFail(activity,UID);
                                break;}
                        }

                    } else {//Week_info is not contains now weeks,remove!
                        authTimeInfoList.remove(i);
                        i--;
                        if(authTimeInfoList.size()>0){//After removal, the List.size()> 0,Continue  the next record!
                            continue;}
                        if(authTimeInfoList.size()==0){//After removal, the List.size() is 0,  comparison fails!
                           compareCardFail(activity,UID);break;}
                    }
                }//authTimeInfo.getWeek_info()==null/equals("")

            }//for
        }

    }
	private boolean compareCollectiveCardDate(CollectiveCardAuthorizationDate authDate, String todayDate) {
		boolean flag = false;
        String[] todayDateArray = null;//todayDate.split(" ");
        if(authDate.getDate_start().contains("-")&&authDate.getDate_end().contains("-")){
            todayDateArray= Timetool.getDateTimeCross().split(" ");
            long nowDate = Timetool.getlongTimeCross(todayDateArray[0]);
            long fromDate = Timetool.getlongTimeCross(authDate.getDate_start());
            long toDate = Timetool.getlongTimeCross(authDate.getDate_end());
            if (nowDate >= fromDate && nowDate <= toDate) {
                flag = true;
            } else {
                flag = false;
            }


        }else if(authDate.getDate_start().contains("/")&&authDate.getDate_end().contains("/")){
            todayDateArray =todayDate.split(" ");
            long nowDate = new Date(todayDateArray[0]).getTime();
            long fromDate = new Date(authDate.getDate_start()).getTime();
            long toDate = new Date(authDate.getDate_end()).getTime();
            if (nowDate >= fromDate && nowDate <= toDate) {
                flag = true;
            } else {
                flag = false;
            }
        }
        return flag;
	}
	






}
