package khdz.click.com.hf_handhelddevice.data;

import java.io.Serializable;


/**
 * Created by Administrator on 2017/7/17.
 */

public class PersonInfo   implements Serializable {
int id;
String person_sn;
String   person_iris_sn;
int sex;
String name;
String   id_card;
String work_sn;
String depart_name;
String   principal_name;
int photo_flag;
private String sortLetters;  //��ʾ����ƴ��������ĸ
    public String getSortLetters() {
	return sortLetters;
}

public void setSortLetters(String sortLetters) {
	this.sortLetters = sortLetters;
}

	public String getPerson_iris_sn() {
        return person_iris_sn;
    }

    public void setPerson_iris_sn(String person_iris_sn) {
        this.person_iris_sn = person_iris_sn;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public String getPerson_sn() {
        return person_sn;
    }

    public void setPerson_sn(String person_sn) {
        this.person_sn = person_sn;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWork_sn() {
        return work_sn;
    }

    public void setWork_sn(String work_sn) {
        this.work_sn = work_sn;
    }

    public String getId_card() {
        return id_card;
    }

    public void setId_card(String id_card) {
        this.id_card = id_card;
    }

    public String getDepart_name() {
        return depart_name;
    }

    public void setDepart_name(String depart_name) {
        this.depart_name = depart_name;
    }

    public String getPrincipal_name() {
        return principal_name;
    }

    public void setPrincipal_name(String principal_name) {
        this.principal_name = principal_name;
    }

    public int getPhoto_flag() {
        return photo_flag;
    }

    public void setPhoto_flag(int photo_flag) {
        this.photo_flag = photo_flag;
    }
}
