package khdz.click.com.hf_handhelddevice.data;

import java.io.Serializable;

public class CollectiveCardAuthorizationDate  implements Serializable{
private    int collective_card_id;
private	   String date_flag;
private	   String date_start;
private	   String date_end;
public int getCollective_card_id() {
	return collective_card_id;
}
public void setCollective_card_id(int collective_card_id) {
	this.collective_card_id = collective_card_id;
}
public String getDate_flag() {
	return date_flag;
}
public void setDate_flag(String date_flag) {
	this.date_flag = date_flag;
}
public String getDate_start() {
	return date_start;
}
public void setDate_start(String date_start) {
	this.date_start = date_start;
}
public String getDate_end() {
	return date_end;
}
public void setDate_end(String date_end) {
	this.date_end = date_end;
}



}
