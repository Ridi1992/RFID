package khdz.click.com.hf_handhelddevice.data;

import java.io.Serializable;


/**
 * Created by Administrator on 2017/7/18.
 */

public class PersonAuthorizationTime implements Serializable {
    int id;
    String person_sn;
    String   person_group;
    String time_start;
    String   time_end;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPerson_sn() {
        return person_sn;
    }

    public void setPerson_sn(String person_sn) {
        this.person_sn = person_sn;
    }

    public String getPerson_group() {
        return person_group;
    }

    public void setPerson_group(String person_group) {
        this.person_group = person_group;
    }

    public String getTime_start() {
        return time_start;
    }

    public void setTime_start(String time_start) {
        this.time_start = time_start;
    }

    public String getTime_end() {
        return time_end;
    }

    public void setTime_end(String time_end) {
        this.time_end = time_end;
    }

    public String getWeek_info() {
        return week_info;
    }

    public void setWeek_info(String week_info) {
        this.week_info = week_info;
    }

    String   week_info;

}
