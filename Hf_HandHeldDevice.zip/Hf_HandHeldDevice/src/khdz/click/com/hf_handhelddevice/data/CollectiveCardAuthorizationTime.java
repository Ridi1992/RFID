package khdz.click.com.hf_handhelddevice.data;

import java.io.Serializable;

public class CollectiveCardAuthorizationTime  implements Serializable{
	private    int collective_card_id;
	private	   String week_info;
	private	   String start_time;
	private	   String end_time;
	public int getCollective_card_id() {
		return collective_card_id;
	}
	public void setCollective_card_id(int collective_card_id) {
		this.collective_card_id = collective_card_id;
	}
	public String getWeek_info() {
		return week_info;
	}
	public void setWeek_info(String week_info) {
		this.week_info = week_info;
	}
	public String getStart_time() {
		return start_time;
	}
	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}
	public String getEnd_time() {
		return end_time;
	}
	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}

}
