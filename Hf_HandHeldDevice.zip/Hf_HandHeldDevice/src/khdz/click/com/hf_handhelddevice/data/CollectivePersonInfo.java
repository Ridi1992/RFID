package khdz.click.com.hf_handhelddevice.data;

import java.io.Serializable;

public class CollectivePersonInfo implements Serializable{
    private  int id;
    private  String person_sn ;
    private  String   camera_name;
    private  String at_position ;
    private  String card_number ;
    private  String camera_sn ;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPerson_sn() {
		return person_sn;
	}
	public void setPerson_sn(String person_sn) {
		this.person_sn = person_sn;
	}
	public String getCamera_name() {
		return camera_name;
	}
	public void setCamera_name(String camera_name) {
		this.camera_name = camera_name;
	}
	public String getAt_position() {
		return at_position;
	}
	public void setAt_position(String at_position) {
		this.at_position = at_position;
	}
	public String getCard_number() {
		return card_number;
	}
	public void setCard_number(String card_number) {
		this.card_number = card_number;
	}
	public String getCamera_sn() {
		return camera_sn;
	}
	public void setCamera_sn(String camera_sn) {
		this.camera_sn = camera_sn;
	}
    
}
