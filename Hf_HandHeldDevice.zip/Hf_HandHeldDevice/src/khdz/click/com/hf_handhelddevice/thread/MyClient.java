package khdz.click.com.hf_handhelddevice.thread;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;



import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.broadcase.SocketReceiver;
import khdz.click.com.hf_handhelddevice.tools.Utils;

/**
 * Created by Administrator on 2017/8/11.
 */

public class MyClient implements Runnable {//
    public static Socket client = null;
    public Intent receiveIntent;
    public String serverIP="";
    public static boolean socketState= true; // Check the server link status����true==close��false==link
    public static  List<Socket> socketList = new ArrayList<Socket>();
    public MyClient( String serverIP) {
        receiveIntent = new Intent();
        receiveIntent.setAction(SocketReceiver.MYACTION);
        this.serverIP=serverIP;
    }

    @Override
    public void run() {
        try {
        	socketState=true;
            client = new Socket(serverIP, 8087);
            client.setKeepAlive(true);
            client.setSoTimeout(1000 * 2);
           while (socketState) {//Continue to receive clients
               // Log.e("�ͻ���", "��������");
                receiveIntent.putExtra("name", "connect");
                MyApplication.getContext().sendOrderedBroadcast(receiveIntent, null);
                doRead( client,serverIP);
            }
        
           
        }catch(UnknownHostException e) {
        	socketState=false;
            getFinish();
        }  catch (SocketException e) {
        	socketState=false;
            getFinish();
           // java.net.ConnectException:    isConnected failed: ECONNREFUSED (Connection refused)
            //java.net.SocketException: failed to connect to ; isConnected failed: EHOSTUNREACH (No route to host)
            //java.net.SocketTimeoutException: failed to connect to /192.168.1.238 (port 8087) after 90000ms
        } catch (IOException e) {
        	socketState=false;
            getFinish();
           // e.printStackTrace();
        }
    }
    public void getFinish() {
//        try {
//            if(MyClient.socketList.size()>0 ) {
//            	 for(Socket  socket:MyClient.socketList){
//            		 socket.close();
//                 }
             //  MyClient.client.close();
//            }
            if(SocketReceiver.socket_ActivityContextList.size()>0){
                for(Activity  context1:SocketReceiver.socket_ActivityContextList){
                    context1.finish();
                }
            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
    }
    private void doRead( Socket client,String serverIP) {
        try {
            //Э��ͷ
            byte[] buffer = new byte[1024];
            int in = client.getInputStream().read(buffer, 0, 12);
            if (in>0&&in == 12) {
            	Log.e("������tou��", "");
            	socketState=true;//The flag has been linked to the server
                socketList.add(client);//Record the link object and loop through the socket link at the end of the interaction to stop the port
               //Log the IP address of each link successfully, and the next time you have a network, link to the address, such as link, then return to the IP address page
                SharedPreferences   preferences = MyApplication.getContext().getSharedPreferences("ServerSocket", Context.MODE_PRIVATE);
                SharedPreferences.Editor   editor = preferences.edit();
                editor.putString("ip", serverIP);
                editor.commit();

                receiveIntent.putExtra("name", "connected");
                MyApplication.getContext().sendOrderedBroadcast(receiveIntent, null);

                int iVersiuon = Utils.byte2intBefor4(buffer);
                int iCommand = Utils.byte2intAfter8(buffer);
                int iPacketLength = Utils.byte2intAfter12(buffer);

                //Protocol header file type
                byte[] headBuffer = new byte[1024];
                int headData = iPacketLength - in;//Length of content after baotou
                int headIn=0;
                if(headData>0 && headData<=1024) {
                    headIn = client.getInputStream().read(headBuffer, 0, headData);
                }
                //  The byte after the first 12 bytes of the protocol is the text type length filename
                if (headIn>0&&headIn == headData) {
                    final int fileType = Utils.byte2intBefor4(headBuffer); // 4 file type, 0 text ,1 head
                  
                 //   Log.e("�ļ�����", fileType+"");
                    
                    int fileLength = Utils.byte2intAfter8(headBuffer); //8byte  long
                  //  Log.e(" after  headData content ==", fileType + "==" + iVersiuon);
                    String fileName;//pc_regester_data
                    // Determines whether the file name is included after the 4 file type + 8 length 12 bytes
                    if (headData - 12 > 0) {//have filename
                        byte[] fialNameByte = new byte[headData - 12];
                        System.arraycopy(headBuffer, 12, fialNameByte, 0, headData - 12);
                        fileName = new String(fialNameByte, 0, fialNameByte.length, "utf-8");
                    } else {//No filename
                        fileName = "pc_regester_data";
                    }
                    //  send info to pc
                    if (iCommand == 32) {
                    //	 Log.e("�ļ�����beginSendData", fileType+"");
                        receiveIntent.putExtra("name", "beginSendData");
                        MyApplication.getContext().sendOrderedBroadcast(receiveIntent, null);
                        long indentifyfileLength = 0;//�ļ�����
                        byte[] write_iVersiuon = Utils.int2byte(iVersiuon);
                        byte[] write_iCommand = Utils.int2byte(iCommand);
                        byte[] PackageNum = Utils.int2byte(24); //����  �汾4�ֽ�+����4�ֽ�+������4�ֽ�+�ļ���С8�ֽڡ�
                        int succeed = 0;
                        byte[] writeNum = Utils.int2byte(succeed); //error code
                        File flie = new File(MyApplication.PERSIN_IDENTIFY_FILE);
                        if (!flie.isDirectory() && flie.exists()) {
                            indentifyfileLength = flie.length();
                        } else {//file not  exists()
                            indentifyfileLength = 0;
                            receiveIntent.putExtra("name", "IdentifyFileNotExists");
                            MyApplication.getContext().sendOrderedBroadcast(receiveIntent, null);
                        }
                        byte[] Length = Utils.int2byte8(indentifyfileLength); //�ļ����� 8�ֽ�
                        byte[] n1 = Utils.byteMerger(write_iVersiuon, write_iCommand);
                        byte[] n2 = Utils.byteMerger(n1, PackageNum);
                        byte[] n3 = Utils.byteMerger(n2, writeNum);
                        byte[] n4 = Utils.byteMerger(n3, Length);
                        boolean sendOver = sendIdentifyDate(client, indentifyfileLength, n4);
                        if (sendOver) {
                            receiveIntent.putExtra("name", "SendDataOver");
                            MyApplication.getContext().sendOrderedBroadcast(receiveIntent, null);
                            byte[] resBuffer = new byte[1024];
                            int resInt = client.getInputStream().read(resBuffer, 0, 12);
                            if (in == 12) {
                                int v = Utils.byte2intBefor4(resBuffer);
                                int rescode =Utils. byte2intAfter8(resBuffer);
                                int l =Utils. byte2intAfter12(resBuffer); 
                                if (rescode == 31) {//32   or 31
                                //	Log.e("���ݽ�����ϣ���������12333", rescode+"");
                                	 byte[] erroe_array3 =  sendCommand(client,2000,30,16,2);
                                     client.getOutputStream().write(erroe_array3);
                                     
                                    receiveIntent.putExtra("name", "deleteFile");
                                    MyApplication.getContext().sendOrderedBroadcast(receiveIntent, null);
                                }
                            }
                        }
                    } else {
                        // receiving the protocol header,Return OK  Command
                        byte[] n3 = sendCommand(client,iVersiuon,iCommand,16,0);
                        client.getOutputStream().write(n3);
                        //Determines whether to send data 0
                        boolean isSave = readReceiveData(client.getInputStream(), fileName, fileType, fileLength);
                        //The data processing received , receiving end of the command 31 success 0, failure: 1, 2
                        if (isSave) {
                            byte[]   receive_array3=sendCommand(client,iVersiuon,31,16,0);
                            client.getOutputStream().write(receive_array3);
                        }
                    }//32
                } else {//Header length error <12
                    //0 succeed,  1  unkown,   2 failed
                    byte[] erroe_array3=  sendCommand(client,iVersiuon,iCommand,16,1);
                    client.getOutputStream().write(erroe_array3);

                }

            } else {
                //Protocol error, return package;
                //0 succeed,  1  unkown,   2 failed
                byte[] erroe_array3 =  sendCommand(client,2000,30,16,2);
                client.getOutputStream().write(erroe_array3);
            }
            //Once the interaction completes, disconnect the link and wait for the next interaction
            //   client.close();
        } catch (SocketException e) {
           e. printStackTrace();

            if(e.toString().contains("EPIPE")){
                receiveIntent.putExtra("name", "Exception");
                MyApplication.getContext().sendOrderedBroadcast(receiveIntent, null);
                socketState=false;//End loop receiving data��and close socket.
                try {client.close();} catch (IOException e1) {e1.printStackTrace();}
            }
          //  Log.e(" SocketException44444==",  e.toString());
            //The server is disconnected and the socket client cannot know if the other side is closed
            // The server disconnects from the link exception��java.net.SocketException: sendto failed: EPIPE (Broken pipe)
        } catch (IOException e) {
            e.printStackTrace();
            socketState=false;//End loop receiving data��and close socket.Wait for the next link
            try {client.close();} catch (IOException e1) {e1.printStackTrace();}
            if(SocketReceiver.socket_ActivityContextList.size()>0){
 //               WelcomeActivity.IS_DOWHILE_FLAG=true;
                for(Activity context1:SocketReceiver.socket_ActivityContextList){
                    context1.finish();
                }
            }
        }
    }


    /**
     * The data interacts with the server, and each time it interacts, the corresponding information file must be deleted
     */
    private boolean readReceiveData(InputStream inputStream, String fileName, int fileType, int fileLength) throws IOException {
        boolean isSave = true;
        FileOutputStream fos=null;
        try {
            File   file=  checkFile(fileType,fileName);
            if(file!=null) {
                 fos = new FileOutputStream(file, false);// if true additional,false== cover
            }
        int iRead = 0;
        byte[] tagLength = new byte[1024];
        while (fileLength > 0) {
            int iReadLen = fileLength > tagLength.length ? tagLength.length : fileLength;
            if ((iRead = inputStream.read(tagLength, 0, iReadLen)) > 0) {
            	//if(fileType==2){ //fileType==2 is person photo,Image unencrypted
                	fos.write(tagLength, 0, iRead);
                    fileLength -= iRead;
//            	}else{//DES Encrypted text message
//           	        try {
//					String aray=DES.encryptDES(tagLength,DES.key);
//					fos.write(aray.getBytes());
//					fileLength -= iRead;
//				    } catch (Exception e) {
//					e.printStackTrace();} 
//            	}
            } else {
                isSave = false;
                break;
            }
        }
        //    if close  inputStream,socket is close,Return package is abnormal
        //      inputStream.close();
        fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return isSave;
    }
    
	
    private File checkFile(int fileType,String fileName) {
        File file = null;
        file = new File(MyApplication.LOCAL_FOLDERS);
        if (!file.isDirectory() || !file.exists()) {
        	  Utils.makeRootDirectory(MyApplication.LOCAL_FOLDERS);//makeRootDirectory
        } else {
        }
        try {
        if (fileType == 1) {
            file = new File(MyApplication.PERSIN_INFO_FILE);
            if (!file.isDirectory() && file.exists()) {
                file.delete();
            } else {
                file.createNewFile();
            }

        } else if (fileType == 2) {
            File  PhotoFile = new File(MyApplication.PHOTO_PATH);
            if(PhotoFile.isDirectory()&& PhotoFile.exists()){
                PhotoFile.delete();
                Utils.makeRootDirectory(MyApplication.PHOTO_PATH);//makeRootDirectory
            }else{
                Utils.makeRootDirectory(MyApplication.PHOTO_PATH);//makeRootDirectory
            }


            file = new File(MyApplication.PHOTO_PATH + fileName);
            MyApplication.deleteNativePhoto(MyApplication.PHOTO_PATH + fileName);
        } else if (fileType == 3) {
            file = new File(MyApplication.PERSIN_AUTH3_FILE);
            if (!file.isDirectory() && file.exists()) {
                file.delete();
            } else {
                file.createNewFile();
            }
        } else if (fileType == 4) {
            file = new File(MyApplication.PERSIN_AUTH4_FILE);
            if (!file.isDirectory() && file.exists()) {
                file.delete();
            } else {
                file.createNewFile();
            }
        } else if (fileType == 5) {
            file = new File(MyApplication.PERSIN_AUTH5_FILE);
            if (!file.isDirectory() && file.exists()) {
                file.delete();
            } else {
                file.createNewFile();
            }
        }else if (fileType == 8) {
            file = new File(MyApplication.COLLECTIVITY_INFO_FILE);
            if (!file.isDirectory() && file.exists()) {
                file.delete();
            } else {
                file.createNewFile();
            }
        }else if (fileType == 9) {
            file = new File(MyApplication.COLLECTIVITY_AUTH9_FILE);
            if (!file.isDirectory() && file.exists()) {
                file.delete();
            } else {
                file.createNewFile();
            }
        }else if (fileType == 10) {
            file = new File(MyApplication.COLLECTIVITY_AUTH10_FILE);
            if (!file.isDirectory() && file.exists()) {
                file.delete();
            } else {
                file.createNewFile();
            }
        }
       } catch (IOException e) {
            e.printStackTrace();
        }
        return  file;
    }

    //**************************************Send identification log records
    //Remove the locally identified data and then delete it.
    public boolean sendIdentifyDate( Socket client, long fileLength, byte[] n4) {
        boolean sendOver = false;
        File file = new File(MyApplication.PERSIN_IDENTIFY_FILE);
        String content = "";
        if (!file.isDirectory() && file.exists()) {
            InputStream in = null;
            try {
                in = new FileInputStream(file);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            InputStreamReader inputreader = new InputStreamReader(in);
            BufferedReader buffreader = new BufferedReader(inputreader);
            byte[] byteArray = new byte[1024];
            int len = 0;
            int temp = 0;//All read content is received using temp
            if (in != null) {
                try {
                    client.getOutputStream().write(n4);
                    while ((temp = in.read(byteArray)) != -1) {    //When not finished, continue reading// while((ch=in.read(byteArray))!=-1){
                        len = len + temp;
                        client.getOutputStream().write(byteArray, 0, temp);
                        if (fileLength == len) {
                            sendOver = true;
                            break;
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    receiveIntent.putExtra("name", "sendIdentifyDataException");
                    MyApplication.getContext().sendOrderedBroadcast(receiveIntent, null);
                }
            }
        } else{// send command
            byte[] n3 =  sendCommand(client,2000,32,16,0);
            try {
                client.getOutputStream().write(n3);
            } catch (IOException e) {
                e.printStackTrace();
            }
       // return;//file is not exists
    }
        return sendOver;
    }


    public   byte[] sendCommand(Socket client,int versiuon,int command,int packageNum,int isSucceedNumber){
            byte[] iVersiuon = Utils.int2byte(versiuon);
            byte[] iCommand = Utils.int2byte(command);
            byte[] PackageNum = Utils.int2byte(packageNum);
            int succeed = isSucceedNumber;
            byte[] succeedNum = Utils.int2byte(succeed);
            byte[] n1 = Utils.byteMerger(iVersiuon, iCommand);
            byte[] n2 = Utils.byteMerger(n1, PackageNum);
            byte[] n3 = Utils.byteMerger(n2, succeedNum);
        return   n3;
}


}
