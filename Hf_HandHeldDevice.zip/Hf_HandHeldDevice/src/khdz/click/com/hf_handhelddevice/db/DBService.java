package khdz.click.com.hf_handhelddevice.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;


import java.util.ArrayList;
import java.util.List;

import khdz.click.com.hf_handhelddevice.data.PersonIdentifyInfo;

public class DBService {
	public static	Context context;
	public static SQLiteDatabase sqLiteDatabase;
	public DBService(Context context){
		this.context=context;
		DBOpenHelper dbOpenHelper=new DBOpenHelper(context);
		sqLiteDatabase=dbOpenHelper.getWritableDatabase();
	}

//*******************************************************************************

public boolean insertIdentifyData(PersonIdentifyInfo personInfo) {
	DBOpenHelper dbOpenHelper=new DBOpenHelper(context);
	sqLiteDatabase=dbOpenHelper.getWritableDatabase();
	boolean  flag=false;
	ContentValues  values=new ContentValues();
	values.put(DBOpenHelper.PERSON_SN,personInfo.getPerson_sn());
	values.put(DBOpenHelper.NAME,personInfo.getName());
	values.put(DBOpenHelper.SEX,personInfo.getSex());
	values.put(DBOpenHelper.ID_CARDER,personInfo.getId_card());
	values.put(DBOpenHelper.WORLK_SN,personInfo.getWork_sn());
	values.put(DBOpenHelper.DEPART_NAME,personInfo.getDepart_name());
	values.put(DBOpenHelper.PRINCIPAL_NAME,personInfo.getPrincipal_name());
	values.put(DBOpenHelper.PERSON_IFIS_SN,personInfo.getPerson_iris_sn());
	values.put(DBOpenHelper.PHOTO_FLAG,personInfo.getPhoto_flag());

	values.put(DBOpenHelper.STATE,personInfo.getState());
	values.put(DBOpenHelper.TIME,personInfo.getTime());
	values.put(DBOpenHelper.LONG_TIME,personInfo.getLong_time());
	long temp = sqLiteDatabase.insert(DBOpenHelper.IDENTIFY_TABLE_NAME, null, values);
	if (temp > 0) {
		flag = true;
	}
	sqLiteDatabase.close();
	return  flag;
}

	public List<PersonIdentifyInfo> selectIdentifyData(){
		List<PersonIdentifyInfo> myList=new ArrayList<PersonIdentifyInfo>();
		Cursor cursor=sqLiteDatabase.query(DBOpenHelper.IDENTIFY_TABLE_NAME, null, null, null, null, null, null);
		while(cursor.moveToNext()){
			int id=cursor.getInt(cursor.getColumnIndex(DBOpenHelper.ID));
			String person_sn=cursor.getString(cursor.getColumnIndex(DBOpenHelper.PERSON_SN));
			String name=cursor.getString(cursor.getColumnIndex(DBOpenHelper.NAME));
			int sex=cursor.getInt(cursor.getColumnIndex(DBOpenHelper.SEX));
			String id_card=cursor.getString(cursor.getColumnIndex(DBOpenHelper.ID_CARDER));
			String work_sn=cursor.getString(cursor.getColumnIndex(DBOpenHelper.WORLK_SN));
			String depart_name=	cursor.getString(cursor.getColumnIndex(DBOpenHelper.DEPART_NAME));
			String principal_name=cursor.getString(cursor.getColumnIndex(DBOpenHelper.PRINCIPAL_NAME));
			String person_iris_sn=cursor.getString(cursor.getColumnIndex(DBOpenHelper.PERSON_IFIS_SN));
			int photo_flag =cursor.getInt(cursor.getColumnIndex(DBOpenHelper.PHOTO_FLAG));
			int state =cursor.getInt(cursor.getColumnIndex(DBOpenHelper.STATE));
			String time =cursor.getString(cursor.getColumnIndex(DBOpenHelper.TIME));
			long long_time =cursor.getLong(cursor.getColumnIndex(DBOpenHelper.LONG_TIME));
			PersonIdentifyInfo persion=new PersonIdentifyInfo();
			persion.setId(id);
			persion.setPerson_sn(person_sn);
			persion.setName(name);
			persion.setSex(sex);
			persion.setId_card(id_card);
			persion.setWork_sn(work_sn);
			persion.setDepart_name(depart_name);
			persion.setPrincipal_name(principal_name);
			persion.setPerson_iris_sn(person_iris_sn);
			persion.setPhoto_flag(photo_flag);
			persion.setState(state);
			persion.setTime(time);
			persion.setLong_time(long_time);
			myList.add(persion);
		}
		cursor.close();
		sqLiteDatabase.close();
		return myList;
	}

	public void deleteIdentifyInfoTable() {
		sqLiteDatabase.execSQL("delete from "+DBOpenHelper.IDENTIFY_TABLE_NAME);

	}





}
