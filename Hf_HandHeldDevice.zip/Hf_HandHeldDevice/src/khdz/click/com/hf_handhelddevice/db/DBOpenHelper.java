package khdz.click.com.hf_handhelddevice.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBOpenHelper extends SQLiteOpenHelper {
    private  static  final String SQLNAME="cards.db";
	private  static  final int  VERSION=1;

	public   static  final String IDENTIFY_TABLE_NAME="identify_PersonInfo";
	public   static  final String STATE="state";
	public   static  final String TIME="time";
	public   static  final String  LONG_TIME="long_time";




	public  static  final String ID="id";
	public  static  final String PERSON_SN="person_sn";
	public  static  final String NAME="name";
	public  static  final String SEX="sex";
	public  static  final String ID_CARDER="id_card";
	public  static  final String WORLK_SN="work_sn";
	public  static  final String DEPART_NAME="depart_name";
	public  static  final String PRINCIPAL_NAME="principal_name";
	public  static  final String PERSON_IFIS_SN="person_iris_sn";
	public  static  final String PHOTO_FLAG="photo_flag";

	public  static  final String PATROL_TABLE="patrol_table" ;

	public DBOpenHelper(Context context) {
		super(context, SQLNAME, null, VERSION);
	}
	@Override
	public void onCreate(SQLiteDatabase database) {
//*********************
		String create="create table "+IDENTIFY_TABLE_NAME+"("+ID+" integer primary key autoincrement, "+PERSON_SN+" varchar(10), "+NAME+" varchar(20),"+SEX+" varchar(15),"+ID_CARDER+" varchar(40),"+WORLK_SN+"  varchar(30),"+DEPART_NAME+"  varchar(30),"+PRINCIPAL_NAME+"  varchar(50),"+PERSON_IFIS_SN+" varchar(30),"+PHOTO_FLAG+" varchar(30),"+
				STATE	+" varchar(30),"+TIME+" varchar(30),"+LONG_TIME +" long );";
		database.execSQL(create);

		String createPatrol="create table "+PATROL_TABLE+"("+ID+" integer primary key autoincrement, "+PERSON_SN+" varchar(10), "+NAME+" varchar(20),"+SEX+" varchar(15),"+ID_CARDER+" varchar(40),"+WORLK_SN+"  varchar(30),"+DEPART_NAME+"  varchar(30),"+PRINCIPAL_NAME+"  varchar(50),"+PERSON_IFIS_SN+" varchar(30),"+PHOTO_FLAG+" varchar(30),"+
				STATE	+" varchar(30),"+TIME+" varchar(30),"+LONG_TIME +" long );";
		database.execSQL(createPatrol);
	}
	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
	}
}
