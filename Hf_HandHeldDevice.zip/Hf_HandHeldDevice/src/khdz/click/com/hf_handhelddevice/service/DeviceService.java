package khdz.click.com.hf_handhelddevice.service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Timer;

import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.activity.Setting_Activity;
import khdz.click.com.hf_handhelddevice.activity.WelcomeActivity;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;

import com.android.rfid.PSAM;
import com.android.rfid.Tools;


public class DeviceService  extends Service{
	protected PSAM mSerialPort;		       //Used to invoke local methods
	protected OutputStream mOutputStream;  //SerialPort OutputStream
	private InputStream mInputStream;      //SerialPort InputStream
	private ReadThread mReadThread;		   //ReadThread
	private final int port = 14;           //Serial number 3
	private Boolean run = true;            // Thread interrupt signal
	private String data = null;            // Returned data
	private StringBuffer data_buffer = new StringBuffer();
	private Timer stopRF;                  //Rf switch timer
	public String activity = "";         //activity==classPackage (sendBroadcast(classPackage));
	/**
	 * Read the thread, read the information returned by the device, and pass it back to the activity that sent the request
	 * @author Jimmy Pang
	 *synchronized
	 */
	private class   ReadThread extends Thread {

		@Override
		public void run() {
			super.run();
			 Looper.prepare();
			while (run) {
				int size;
				try {
					byte[] buffer = new byte[128];
					if (mInputStream == null)
						return;
					size = mInputStream.read(buffer);
					if (size > 0) {
						data = Tools.Bytes2HexString(buffer, size);
						data_buffer.append(data);
						data = null;
						if(data_buffer.toString().length() > 10){
							String dataLen = data_buffer.substring(2, 6); 
							
							
						//	Log.e("dataLength==", dataLen+"==data==" +data_buffer.toString());
							if(Tools.checkData(dataLen, data_buffer.toString())){
						//		Log.e("DeviceService data=="+activity+"==", data_buffer.toString());
								Intent serviceIntent = new Intent();
								serviceIntent.setAction(activity);
								serviceIntent.putExtra("result", data_buffer.toString());
								serviceIntent.putExtra("activity", activity);
								data_buffer.setLength(0);
								sendBroadcast(serviceIntent);
							}
							
//							else{
//									 Log.e("eeeeeeeeeeeeeeeeeeeeeeeee888888", "== "+activity);
//							
//							}
							
							
							
						}else{
							data_buffer.setLength(0);
						}
						 
					}
				} catch (IOException e) {
					e.printStackTrace();
					return;
				}
			}
			 Looper.loop();
		}
	}
	
	

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
	@Override
	public void onCreate() {
		super.onCreate();
		init();
	}
	private void init(){
		try {
			mSerialPort = new PSAM(port, 115200); 
			//Open the serial port, the port number of the device is set to 3, and the baud rate is 115200
		} catch (SecurityException e) {e.printStackTrace();
		} catch (IOException e) {e.printStackTrace();}
		if(mSerialPort == null){  //no devices
			return;
		}
		mSerialPort.PowerOn_HFPsam(); // PowerOn SerialPort
		mOutputStream = mSerialPort.getOutputStream();
		mInputStream = mSerialPort.getInputStream();

		/* Create a receiving thread */
		mReadThread = new ReadThread();
		mReadThread.start(); 
		
		
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		try {
		if (intent.getByteArrayExtra("cmd") == null)
			return 0; 
		} catch (NullPointerException e) {
			e.printStackTrace();
			return 0;
		} 
		String ac = intent.getStringExtra("activity");
		if(ac!=null){
		activity=ac;//BroadcastReceiver action ==activity
		}else if(ac.equals("stopflag")){
				Myclose();
			
		}else{
			activity="";
		}
		
		try {
			mOutputStream.write(intent.getByteArrayExtra("cmd")); //write  cmd
		} catch (IOException e) {
			e.printStackTrace();
		}
		return 0;
	}

	private void Myclose() {
		stopSelf(); // �յ�ֹͣ�����ź�
	}
	@Override
	public void onDestroy() {
		if (mReadThread != null)
			run = false; 					// Destroy mReadThread
		mSerialPort.PowerOff_HFPsam(); 		// PowerOff  SerialPort
		mSerialPort.close(port); 			// close SerialPort port
		super.onDestroy();
	}

	
	
}
